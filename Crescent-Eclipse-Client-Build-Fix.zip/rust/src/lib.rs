//! JNI native helper. Keep JNI calls coarse-grained; per-frame calls can cost more than they save.
use std::ffi::c_void;
#[allow(non_snake_case)]
#[no_mangle]
pub extern "system" fn Java_dev_eclipse_client_nativebridge_NativeBridge_rustClamp(
    _env: *mut c_void, _class: *mut c_void, value: i32, min: i32, max: i32,
) -> i32 { value.clamp(min, max) }
