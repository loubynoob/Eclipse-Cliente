# Crescent Eclipse-Client — Rust + Fabric (Android ARM64 integration)

This source project keeps the Fabric/Java client entrypoint and adds an optional Rust JNI library. The Gradle build is configured to compile Rust for Android ARM64 and embed the resulting shared library in the mod JAR.

## What is configured

- Gradle task `installRustAndroidTarget` installs Rust's `aarch64-linux-android` target.
- Gradle task `buildRustAndroidArm64` invokes Cargo with the Android NDK Clang linker (Android API 26 minimum).
- Gradle task `packageRustAndroidArm64` stages `libcrescent_native.so` under `META-INF/native/android-arm64-v8a/`.
- `processResources` and `build` depend on the native build/package task.
- `NativeBridge` extracts the bundled `.so` on ARM64 Android and loads it with `System.load`. If the native library is missing or cannot load, it falls back to Java so the mod can still start.

## Build environment required

Use a computer or build environment with:

1. JDK 25 (required by Minecraft 26.1.2).
2. Internet access on first run so `gradlew` can download the pinned Gradle 9.2.1 distribution.
3. Internet access for Gradle and Minecraft/Fabric dependencies.

Rust and the Android NDK are OPTIONAL. The standard Fabric JAR uses the Java fallback. The Android native library can be built separately with `gradle packageRustAndroidArm64` in an NDK-equipped environment.

Then run from the project root:

```sh
./gradlew build
```

The output Fabric mod JAR will be in `build/libs/`. The native library is compiled for Android `arm64-v8a` only, with Android API 26 as the minimum target.

## Verified build versions

The build is configured for Minecraft 26.1.2, Fabric Loader 0.19.3, Fabric API 0.155.3+26.1.2, Fabric Loom 1.14.10, Gradle 9.2.1, and Java 25. These versions are selected for the 26.1.2 toolchain.

## Important limitations

- This does not port the HUD renderer or Minecraft API-facing code to Rust. It establishes a small JNI bridge and a build/package pipeline for the Rust library.
- Rust does not automatically improve FPS; JNI calls should remain coarse-grained and be benchmarked.
- The Android native library is for ARM64 only. Desktop users will use the Java fallback unless a desktop native build is added.
- A GitHub Actions workflow is included at `.github/workflows/build.yml`. It installs Java 25 and Gradle 9.2.1, builds the Fabric JAR, and uploads it as an Actions artifact. The project was structurally checked here, but the Minecraft compile still must run in GitHub Actions before the JAR can be called tested.


## UI changes in this revision
- Removed the title-screen panorama rendering and bundled panorama face textures.
- Changed glass panels, cards, and inactive controls to neutral translucent white/charcoal surfaces with subtle white rims.
- Removed purple-tinted loading, inventory, and sky-screen overlays. The red active-state accent remains.
