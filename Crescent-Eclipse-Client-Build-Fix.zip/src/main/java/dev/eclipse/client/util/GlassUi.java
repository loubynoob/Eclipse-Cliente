package dev.eclipse.client.util;

import dev.eclipse.client.EclipseClient;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.resources.Identifier;

import java.util.HashMap;
import java.util.Map;

/**
 * Eclipse UI pieces: midnight dark-red, rounded, layered (soft shadow, gradient body, thin bright rim,
 * top sheen) plus drawn icons. Everything is plain fills and small PNG icons, so it needs no shaders.
 * (Class name kept for older screens.)
 */
public final class GlassUi {
    private GlassUi() {}

    public static final int ACCENT = 0xFFE0344F;
    public static final int ACCENT_LIGHT = 0xFFFF9AA6;
    public static final int ACCENT_DARK = 0xFF7A1226;
    // older names, same colours
    public static final int PURPLE = ACCENT;
    public static final int PURPLE_LIGHT = ACCENT_LIGHT;
    public static final int PURPLE_DARK = ACCENT_DARK;
    public static final int BG = 0x4012161C;
    public static final int PANEL = 0x38FFFFFF;
    public static final int PANEL_HOVER = 0x50FFFFFF;
    public static final int BORDER = 0x55FFFFFF;
    public static final int TEXT = 0xFFFFEFF1;
    public static final int DIM = 0xFFB08A92;

    // ---------- shapes ----------
    private static int lerp(int a, int b, float t) {
        t = Math.max(0f, Math.min(1f, t));
        int aa = (int) (((a >>> 24) & 255) + (((b >>> 24) & 255) - ((a >>> 24) & 255)) * t);
        int ar = (int) (((a >> 16) & 255) + (((b >> 16) & 255) - ((a >> 16) & 255)) * t);
        int ag = (int) (((a >> 8) & 255) + (((b >> 8) & 255) - ((a >> 8) & 255)) * t);
        int ab = (int) ((a & 255) + ((b & 255) - (a & 255)) * t);
        return (aa << 24) | (ar << 16) | (ag << 8) | ab;
    }

    private static int inset(int i, int r) {
        double dy = r - i - 0.5;
        double dx = Math.sqrt(Math.max(0, (double) r * r - dy * dy));
        return (int) Math.ceil(r - dx);
    }

    /** Rounded rectangle with a vertical gradient. */
    public static void round(GuiGraphicsExtractor g, int x, int y, int w, int h, int r, int top, int bottom) {
        if (w <= 0 || h <= 0) return;
        r = Math.max(0, Math.min(r, Math.min(w, h) / 2));
        for (int i = 0; i < h; i++) {
            int ins = i < r ? inset(i, r) : (i >= h - r ? inset(h - 1 - i, r) : 0);
            g.fill(x + ins, y + i, x + w - ins, y + i + 1, lerp(top, bottom, h <= 1 ? 0f : i / (float) (h - 1)));
        }
    }

    public static void round(GuiGraphicsExtractor g, int x, int y, int w, int h, int r, int color) {
        round(g, x, y, w, h, r, color, color);
    }

    /** One-pixel rounded outline, gradient from top to bottom colour. */
    public static void rim(GuiGraphicsExtractor g, int x, int y, int w, int h, int r, int top, int bottom) {
        if (w <= 1 || h <= 1) return;
        r = Math.max(0, Math.min(r, Math.min(w, h) / 2));
        for (int i = 0; i < h; i++) {
            int ins = i < r ? inset(i, r) : (i >= h - r ? inset(h - 1 - i, r) : 0);
            int c = lerp(top, bottom, i / (float) (h - 1));
            if (i == 0 || i == h - 1) {
                g.fill(x + ins, y + i, x + w - ins, y + i + 1, c);
            } else {
                int next = i + 1 < r ? inset(i + 1, r) : (i + 1 >= h - r ? inset(h - 2 - i, r) : 0);
                int span = Math.max(1, Math.abs(ins - next));
                g.fill(x + ins, y + i, x + ins + span, y + i + 1, c);
                g.fill(x + w - ins - span, y + i, x + w - ins, y + i + 1, c);
            }
        }
    }

    /** Soft shadow around a rounded box. */
    public static void shadow(GuiGraphicsExtractor g, int x, int y, int w, int h, int r) {
        for (int i = 4; i >= 1; i--) {
            round(g, x - i, y - i + 2, w + 2 * i, h + 2 * i, r + i, (0x0E + (4 - i) * 0x04) << 24);
        }
    }

    /** Opaque colour of the big panel body at height fraction t (0 top .. 1 bottom); used to cover scroll overflow. */
    public static int panelTint(float t) {
        return lerp(0x38FFFFFF, 0x2412161C, t);
    }

    // ---------- pieces ----------
    public static void panel(GuiGraphicsExtractor g, int x, int y, int w, int h) {
        panel(g, x, y, w, h, 6);
    }

    public static void panel(GuiGraphicsExtractor g, int x, int y, int w, int h, int r) {
        shadow(g, x, y, w, h, r);
        round(g, x, y, w, h, r, 0x48FFFFFF, 0x2812161C);
        round(g, x + 1, y + 1, w - 2, Math.max(2, h / 6), Math.max(1, r - 1), 0x24FFFFFF, 0x00FFFFFF);   // top sheen
        rim(g, x, y, w, h, r, 0x88FFFFFF, 0x38FFFFFF);
    }

    public static void card(GuiGraphicsExtractor g, int x, int y, int w, int h, boolean hover, boolean selected) {
        card(g, x, y, w, h, hover, selected, false);
    }

    public static void card(GuiGraphicsExtractor g, int x, int y, int w, int h, boolean hover, boolean selected, boolean enabled) {
        int r = Math.min(5, h / 2);
        round(g, x, y, w, h, r, hover ? 0x58FFFFFF : 0x38FFFFFF, hover ? 0x4812161C : 0x2812161C);
        if (enabled) {
            round(g, x + 1, y + 1, w - 2, Math.max(2, h / 2), Math.max(1, r - 1), 0x30E0344F, 0x00E0344F);
            g.fill(x + r, y, x + w - r, y + 2, ACCENT);
        } else {
            round(g, x + 1, y + 1, w - 2, Math.max(2, h / 3), Math.max(1, r - 1), 0x10FFFFFF, 0x00FFFFFF);
        }
        if (selected) rim(g, x, y, w, h, r, ACCENT_LIGHT, ACCENT);
        else rim(g, x, y, w, h, r, hover ? 0x70FFFFFF : 0x3CFFFFFF, 0x1AFFFFFF);
    }

    public static void button(GuiGraphicsExtractor g, int x, int y, int w, int h, boolean hover, boolean on) {
        int r = Math.min(4, h / 2);
        if (on) {
            round(g, x, y, w, h, r, hover ? 0xFFF0566B : 0xFFE0344F, hover ? 0xFFB02440 : 0xFF8A1A30);
            round(g, x + 1, y + 1, w - 2, Math.max(2, h / 2), Math.max(1, r - 1), 0x40FFFFFF, 0x00FFFFFF);
            rim(g, x, y, w, h, r, ACCENT_LIGHT, 0xFFB02440);
        } else {
            round(g, x, y, w, h, r, hover ? 0x58FFFFFF : 0x38FFFFFF, hover ? 0x4812161C : 0x2812161C);
            round(g, x + 1, y + 1, w - 2, Math.max(2, h / 2), Math.max(1, r - 1), 0x12FFFFFF, 0x00FFFFFF);
            rim(g, x, y, w, h, r, hover ? 0x80FFFFFF : 0x40FFFFFF, 0x1CFFFFFF);
        }
    }

    public static void accent(GuiGraphicsExtractor g, int x, int y, int w, int h, boolean hover) {
        int r = Math.min(4, h / 2);
        round(g, x, y, w, h, r, hover ? 0xFFF8647A : 0xFFE8405A, hover ? 0xFF8F1B33 : 0xFF6A1226);
        round(g, x + 1, y + 1, w - 2, Math.max(2, h / 2), Math.max(1, r - 1), 0x38FFFFFF, 0x00FFFFFF);
        rim(g, x, y, w, h, r, ACCENT_LIGHT, 0xFFB02440);
    }

    public static void danger(GuiGraphicsExtractor g, int x, int y, int w, int h, boolean hover) {
        int r = Math.min(4, h / 2);
        round(g, x, y, w, h, r, hover ? 0xFF5E1A24 : 0xFF45121A, hover ? 0xFF35090F : 0xFF2A0A10);
        round(g, x + 1, y + 1, w - 2, Math.max(2, h / 2), Math.max(1, r - 1), 0x18FFFFFF, 0x00FFFFFF);
        rim(g, x, y, w, h, r, 0xFFB04050, 0xFF6A2230);
    }

    /** Compatibility alias for older call sites. */
    public static void pill(GuiGraphicsExtractor g, int x, int y, int w, int h, boolean hover, boolean accent) {
        button(g, x, y, w, h, hover, accent);
    }

    /** Rounded on/off switch, 20 x 10. */
    public static void toggle(GuiGraphicsExtractor g, int x, int y, boolean on) {
        if (on) round(g, x, y, 20, 10, 5, 0xFFF0566B, 0xFFB02440);
        else round(g, x, y, 20, 10, 5, 0x48FFFFFF, 0x2812161C);
        rim(g, x, y, 20, 10, 5, on ? ACCENT_LIGHT : 0x50FFFFFF, on ? 0xFFB02440 : 0x20FFFFFF);
        round(g, on ? x + 11 : x + 1, y + 1, 8, 8, 4, on ? 0xFFFFFFFF : 0xFF8A6A72, on ? 0xFFFFD9DE : 0xFF6E4A53);
    }

    /** "Enabled" / "Disabled" button used on module cards. */
    public static void enabledButton(GuiGraphicsExtractor g, Font font, int x, int y, int w, int h, boolean hover, boolean on) {
        int r = Math.min(4, h / 2);
        if (on) {
            round(g, x, y, w, h, r, hover ? 0xFFF0566B : 0xFFD42A47, 0xFF7A1226);
            round(g, x + 1, y + 1, w - 2, Math.max(2, h / 2), Math.max(1, r - 1), 0x38FFFFFF, 0x00FFFFFF);
            rim(g, x, y, w, h, r, ACCENT_LIGHT, 0xFF9A1B32);
        } else {
            round(g, x, y, w, h, r, hover ? 0x58FFFFFF : 0x38FFFFFF);
            rim(g, x, y, w, h, r, hover ? 0x70FFFFFF : 0x30FFFFFF, 0x14FFFFFF);
        }
        String t = on ? "Enabled" : "Disabled";
        g.text(font, t, x + (w - font.width(t)) / 2, y + (h - 8) / 2, on ? 0xFFFFFFFF : DIM, false);
    }

    public static void segmentBar(GuiGraphicsExtractor g, int x, int y, int w, int h) {
        round(g, x, y, w, h, h / 2, 0x38FFFFFF);
        rim(g, x, y, w, h, h / 2, 0x40FFFFFF, 0x18FFFFFF);
    }

    // ---------- icons ----------
    private static final Map<String, Identifier> ICONS = new HashMap<>();

    private static Identifier iconId(String name, boolean bright) {
        String key = name + (bright ? "" : "_dim");
        return ICONS.computeIfAbsent(key, k ->
                Identifier.fromNamespaceAndPath(EclipseClient.MOD_ID, "textures/gui/icons/" + k + ".png"));
    }

    /** Draws a 32x32 icon texture scaled to {@code size} pixels. */
    public static void icon(GuiGraphicsExtractor g, String name, int x, int y, int size, boolean bright) {
        float k = size / 32f;
        g.pose().pushMatrix();
        g.pose().translate(x, y);
        g.pose().scale(k, k);
        g.blit(RenderPipelines.GUI_TEXTURED, iconId(name, bright), 0, 0, 0f, 0f, 32, 32, 32, 32);
        g.pose().popMatrix();
    }
}
