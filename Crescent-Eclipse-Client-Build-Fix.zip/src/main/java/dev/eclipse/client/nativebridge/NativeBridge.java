package dev.eclipse.client.nativebridge;

import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;

/** Optional Rust-backed helpers. The native library is extracted from the mod JAR on Android. */
public final class NativeBridge {
    private static final boolean AVAILABLE = loadNativeLibrary();

    private NativeBridge() {}

    private static boolean loadNativeLibrary() {
        // First allow a developer-provided library path (useful for desktop testing).
        try {
            System.loadLibrary("crescent_native");
            return true;
        } catch (LinkageError | SecurityException ignored) {
            // Continue with the Android ARM64 library bundled in this mod.
        }

        String arch = System.getProperty("os.arch", "").toLowerCase();
        if (!(arch.equals("aarch64") || arch.equals("arm64"))) return false;

        String resource = "/META-INF/native/android-arm64-v8a/libcrescent_native.so";
        try (InputStream in = NativeBridge.class.getResourceAsStream(resource)) {
            if (in == null) return false; // Java fallback keeps the mod usable without native support.
            Path extracted = Files.createTempFile("crescent-native-", ".so");
            extracted.toFile().deleteOnExit();
            Files.copy(in, extracted, StandardCopyOption.REPLACE_EXISTING);
            System.load(extracted.toAbsolutePath().toString());
            return true;
        } catch (IOException | LinkageError | SecurityException ignored) {
            return false;
        }
    }

    private static native int rustClamp(int value, int min, int max);

    public static int clamp(int value, int min, int max) {
        if (min > max) {
            int t = min;
            min = max;
            max = t;
        }
        return AVAILABLE ? rustClamp(value, min, max) : Math.max(min, Math.min(max, value));
    }

    public static boolean isRustAvailable() {
        return AVAILABLE;
    }
}
