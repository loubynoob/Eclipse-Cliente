Original archive inspection:
- Outer ZIP contained `eclipse-client-1.0.4-sources.jar` and `eclipse-client-1.0.4.jar`.
- Source JAR contained 52 `.java` files plus Fabric metadata, mixin config, and assets.
- Original `fabric.mod.json` declared Minecraft `~26.1`, Java `>=25`, Fabric Loader `>=0.17.0`, and Fabric API `*`.
- No Gradle wrapper, Gradle build file, or Rust crate was present.
