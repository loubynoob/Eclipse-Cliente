package dev.eclipse.client.screen;

import com.mojang.realmsclient.RealmsMainScreen;
import dev.eclipse.client.util.Branding;
import dev.eclipse.client.util.GlassUi;
import net.minecraft.ChatFormatting;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.TitleScreen;
import net.minecraft.client.gui.screens.multiplayer.JoinMultiplayerScreen;
import net.minecraft.client.gui.screens.options.OptionsScreen;
import net.minecraft.client.gui.screens.worldselection.SelectWorldScreen;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.network.chat.Component;

import java.util.ArrayList;
import java.util.List;

/**
 * Eclipse main menu: dark panorama, big logo + name, stacked rounded buttons with icons, a highlighted
 * Eclipse Settings button, red Quit, and an account / quick-button bar in the top-right corner.
 * Layout idea inspired by Fast Client - thanks NoduweyLo.
 */
public class EclipseTitleScreen extends TitleScreen {
    private record Hit(int x, int y, int w, int h, Runnable run) {}

    private final List<Hit> hits = new ArrayList<>();

    public EclipseTitleScreen() { super(); }

    @Override
    protected void init() {
        // deliberately NOT calling super.init(): this screen draws and handles its own buttons
    }

    private static boolean in(int px, int py, int x, int y, int w, int h) {
        return px >= x && px < x + w && py >= y && py < y + h;
    }

    /** Wide menu button: rounded, icon + centred label. */
    private void wide(GuiGraphicsExtractor g, String icon, String label, int x, int y, int w, int h, int mx, int my, Runnable r) {
        boolean hov = in(mx, my, x, y, w, h);
        GlassUi.button(g, x, y, w, h, hov, false);
        int tw = font.width(label);
        int start = x + w / 2 - (tw + 14) / 2;
        GlassUi.icon(g, icon, start, y + (h - 10) / 2, 10, hov);
        g.text(font, label, start + 14, y + (h - 8) / 2, hov ? 0xFFFFFFFF : GlassUi.TEXT, false);
        hits.add(new Hit(x, y, w, h, r));
    }

    /** Small square icon button for the top-right bar. */
    private int square(GuiGraphicsExtractor g, String icon, int right, int y, int mx, int my, Runnable r) {
        int s = 18, x = right - s;
        boolean hov = in(mx, my, x, y, s, s);
        GlassUi.button(g, x, y, s, s, hov, false);
        GlassUi.icon(g, icon, x + 4, y + 4, 10, true);
        hits.add(new Hit(x, y, s, s, r));
        return x - 4;
    }

    @Override
    public void extractRenderState(GuiGraphicsExtractor g, int mx, int my, float delta) {
        super.extractRenderState(g, mx, my, delta);          // panorama
        hits.clear();
        g.fill(0, 0, width, height, 0x88000000);             // darken
        g.fillGradient(0, 0, width, height / 3, 0x60000000, 0x00000000);
        g.fillGradient(0, height * 2 / 3, width, height, 0x00000000, 0x70000000);

        int cx = width / 2;

        // ---- top-right bar: account + quick buttons ----
        int by = 6, right = width - 6;
        right = square(g, "ui_gear", right, by, mx, my, () -> minecraft.setScreen(new OptionsScreen(this, minecraft.options, true)));
        right = square(g, "ui_globe", right, by, mx, my, () -> minecraft.setScreen(new RealmsMainScreen(this)));
        right = square(g, "ui_sliders", right, by, mx, my, () -> minecraft.setScreen(new HudEditorScreen(this)));
        String user = minecraft.getUser().getName();
        int ub = font.width(user) + 26;
        GlassUi.button(g, right - ub, by, ub, 18, false, false);
        GlassUi.icon(g, "ui_person", right - ub + 6, by + 4, 10, true);
        g.text(font, user, right - ub + 20, by + 5, 0xFFFFFFFF, false);

        // ---- logo + name ----
        int bw = Math.max(160, Math.min(220, width / 4)), bh = 20, gap = 4;
        int total = 48 + 12 + 4 * (bh + gap) + 10 + 20 + 14;
        int y0 = Math.max(26, height / 2 - total / 2);
        Component name = Component.literal("ECLIPSE CLIENT").withStyle(ChatFormatting.BOLD);
        float ns = 1.6f;
        int nw = (int) (font.width(name) * ns);
        int rowW = 48 + 8 + nw, rx = cx - rowW / 2;
        g.pose().pushMatrix();
        g.pose().translate(rx, y0);
        g.pose().scale(0.75f, 0.75f);
        g.blit(RenderPipelines.GUI_TEXTURED, Branding.LOGO64, 0, 0, 0f, 0f, 64, 64, 64, 64);
        g.pose().popMatrix();
        g.pose().pushMatrix();
        g.pose().translate(rx + 56, y0 + 24 - 4 * ns);
        g.pose().scale(ns, ns);
        g.text(font, name, 0, 0, 0xFFFFFFFF, true);
        g.pose().popMatrix();

        // ---- buttons ----
        int y = y0 + 60, x = cx - bw / 2;
        wide(g, "ui_person", "Singleplayer", x, y, bw, bh, mx, my, () -> minecraft.setScreen(new SelectWorldScreen(this)));
        y += bh + gap;
        wide(g, "ui_people", "Multiplayer", x, y, bw, bh, mx, my, () -> minecraft.setScreen(new JoinMultiplayerScreen(this)));
        y += bh + gap;
        wide(g, "ui_grid", "Mods", x, y, bw, bh, mx, my, () -> minecraft.setScreen(new ModMenuScreen(this, null)));
        y += bh + gap;
        boolean hs = in(mx, my, x, y, bw, bh);
        GlassUi.accent(g, x, y, bw, bh, hs);
        String es = "Eclipse Settings";
        int estart = cx - (font.width(es) + 14) / 2;
        GlassUi.icon(g, "ui_star", estart, y + (bh - 10) / 2, 10, true);
        g.text(font, es, estart + 14, y + (bh - 8) / 2, 0xFFFFFFFF, true);
        hits.add(new Hit(x, y, bw, bh, () -> minecraft.setScreen(new HudEditorScreen(this))));
        y += bh + gap + 10;

        int qw = 96, qx = cx - qw / 2;
        boolean hq = in(mx, my, qx, y, qw, 18);
        GlassUi.danger(g, qx, y, qw, 18, hq);
        g.text(font, "Quit Game", cx - font.width("Quit Game") / 2, y + 5, 0xFFFFFFFF, false);
        hits.add(new Hit(qx, y, qw, 18, () -> minecraft.stop()));

        String ver = "Eclipse Client " + Branding.ECLIPSE_BUILD;
        g.text(font, ver, cx - font.width(ver) / 2, y + 24, GlassUi.DIM, false);

        // bottom-right logo + name, bottom-left version, same as every other screen
        Branding.draw(g, width, height);
    }

    @Override
    public boolean mouseClicked(MouseButtonEvent e, boolean dbl) {
        int x = (int) e.x(), y = (int) e.y();
        for (int i = hits.size() - 1; i >= 0; i--) {
            Hit h = hits.get(i);
            if (in(x, y, h.x(), h.y(), h.w(), h.h())) { h.run().run(); return true; }
        }
        return super.mouseClicked(e, dbl);
    }
}
