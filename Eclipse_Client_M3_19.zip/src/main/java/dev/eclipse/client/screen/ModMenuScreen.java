package dev.eclipse.client.screen;

import dev.eclipse.client.config.EclipseConfig;
import dev.eclipse.client.hud.HudModule;
import dev.eclipse.client.mod.ModEntry;
import dev.eclipse.client.mod.ModRegistry;
import dev.eclipse.client.mod.SettingsUi;
import dev.eclipse.client.util.ColorUtil;
import dev.eclipse.client.util.GlassUi;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.function.Consumer;

/**
 * Eclipse Mod Menu: a scrollable grid of module cards (Enabled / Disabled + settings button).
 * Opening a module's settings slides a panel in from the right. Drag with the mouse (left or right button)
 * or use the wheel to scroll.  Dark purple and black.
 */
public class ModMenuScreen extends Screen implements SettingsUi {
    private record Hit(int x, int y, int w, int h, Runnable run, int region) {}

    private static final int RH = 14;
    private static final String[] PRESETS = {"All HUDs", "PvP", "Minimal", "None"};

    private final Screen parent;
    private ModEntry sel;
    private int cat;

    private final List<Hit> hits = new ArrayList<>();
    private int mx, my;
    private float anim, scrollG, scrollS;
    private int maxG, maxS;

    private EditBox search;
    private final Map<String, EditBox> boxes = new HashMap<>();

    // drag-to-scroll state
    private Hit pending;
    private boolean dragged;
    private int pressX, pressY, dragRegion;

    // settings rows (one region at a time)
    private int rowX, rowW, viewTop, viewBottom, cy;

    private int presetIdx = -1;
    private String status = "";
    private long statusUntil;

    // layout
    private int winX, winY, winW, winH, gridTop, gridBottom, gridLeft, gridRight, panelX, panelW;

    public ModMenuScreen(Screen parent, ModEntry preselect) {
        super(Component.literal("Eclipse Mods"));
        this.parent = parent;
        this.sel = preselect;
        cat = Math.max(0, Math.min(ModRegistry.CATEGORIES.length - 1, EclipseConfig.get().modMenuCat));
        if (preselect != null) anim = 0f;
    }

    private static boolean in(int px, int py, int x, int y, int w, int h) {
        return px >= x && px < x + w && py >= y && py < y + h;
    }

    @Override
    protected void init() {
        String old = search != null ? search.getValue() : "";
        clearWidgets();
        boxes.clear();
        search = new EditBox(font, -200, -200, 52, 12, Component.literal("Search"));
        search.setMaxLength(24);
        search.setValue(old);
        addRenderableWidget(search);
    }

    private void select(ModEntry e) {
        sel = e;
        scrollS = 0;
        init();
    }

    private void closePanel() {
        sel = null;
        init();
    }

    private List<ModEntry> filtered() {
        String q = search == null ? "" : search.getValue().trim().toLowerCase(Locale.ROOT);
        List<ModEntry> out = new ArrayList<>();
        for (ModEntry e : ModRegistry.all()) {
            if (cat != 0 && !e.category.equals(ModRegistry.CATEGORIES[cat])) continue;
            if (!q.isEmpty() && !e.name.toLowerCase(Locale.ROOT).contains(q)) continue;
            out.add(e);
        }
        return out;
    }

    private String fit(String s, int maxW) {
        if (font.width(s) <= maxW) return s;
        while (s.length() > 1 && font.width(s + "..") > maxW) s = s.substring(0, s.length() - 1);
        return s + "..";
    }

    // ================= top bar (header + tabs) =================
    /** Lays out the header and tab rows; draws them when {@code draw}. Returns the y where the grid starts. */
    private int top(GuiGraphicsExtractor g, boolean draw) {
        int left = winX + 5, right = winX + winW - 5;
        int y = winY + 5;
        if (draw) {
            GlassUi.accent(g, left, y, 74, 16, false);
            GlassUi.icon(g, "ui_grid", left + 5, y + 3, 10, true);
            g.text(font, "MOD MENU", left + 19, y + 4, 0xFFFFFFFF, true);
            int ex = left + 78;
            boolean hov = in(mx, my, ex, y, 62, 16);
            GlassUi.button(g, ex, y, 62, 16, hov, false);
            GlassUi.icon(g, "ui_monitor", ex + 5, y + 3, 10, true);
            g.text(font, "Edit HUD", ex + 19, y + 4, GlassUi.TEXT, false);
            hits.add(new Hit(ex, y, 62, 16, () -> minecraft.setScreen(new HudEditorScreen(parent)), 0));
            if (System.currentTimeMillis() < statusUntil) {
                g.text(font, status, ex + 68, y + 4, GlassUi.PURPLE_LIGHT, false);
            }
            boolean hc = in(mx, my, right - 16, y, 16, 16);
            GlassUi.danger(g, right - 16, y, 16, 16, hc);
            GlassUi.icon(g, "ui_close", right - 12, y + 4, 8, true);
            hits.add(new Hit(right - 16, y, 16, 16, this::onClose, 0));
        }
        y += 20;
        int x = left;
        String[] cats = ModRegistry.CATEGORIES;
        int n = cats.length;
        for (int i = 0; i < n + 3; i++) {
            String label;
            int w;
            if (i < n) { label = cats[i]; w = font.width(label) + 10; }
            else if (i == n) { label = "Reset"; w = font.width(label) + 10; }
            else if (i == n + 1) { label = "Presets"; w = font.width(label) + 10; }
            else { label = null; w = 80; }
            if (x + w > right && x > left) { x = left; y += 16; }
            if (draw) {
                if (label != null) {
                    boolean on = i < n && i == cat;
                    boolean hov = in(mx, my, x, y, w, 14);
                    GlassUi.button(g, x, y, w, 14, hov, on);
                    g.text(font, label, x + w / 2 - font.width(label) / 2, y + 3, on || i >= n ? 0xFFFFFFFF : GlassUi.DIM, false);
                    final int idx = i;
                    hits.add(new Hit(x, y, w, 14, () -> {
                        if (idx < n) { cat = idx; EclipseConfig.get().modMenuCat = idx; scrollG = 0; }
                        else if (idx == n) resetSelected();
                        else cyclePreset();
                    }, 0));
                } else {
                    GlassUi.icon(g, "zoom", x + 2, y + 2, 10, false);
                    GlassUi.round(g, x + 13, y, 68, 14, 4, 0xFF0C0609);
                    GlassUi.rim(g, x + 13, y, 68, 14, 4, 0x50FFFFFF, 0x20FFFFFF);
                    search.setX(x + 25);
                    search.setY(y + 1);
                }
            }
            x += w + 3;
        }
        return y + 14 + 4;
    }

    private void resetSelected() {
        if (sel == null) { status = "Open a module first"; statusUntil = System.currentTimeMillis() + 2000; return; }
        sel.reset();
        status = sel.name + " reset";
        statusUntil = System.currentTimeMillis() + 2000;
        init();
    }

    private void cyclePreset() {
        presetIdx = (presetIdx + 1) % PRESETS.length;
        for (ModEntry e : ModRegistry.all()) {
            HudModule m = e.hud();
            if (m == null) continue;
            boolean on = switch (presetIdx) {
                case 0 -> true;
                case 1 -> switch (m.id) {
                    case "fps", "cps", "keystrokes", "armor", "potions", "ping", "combo", "movement", "tnt", "health" -> true;
                    default -> false;
                };
                case 2 -> m.id.equals("fps");
                default -> false;
            };
            e.setEnabled(on);
        }
        status = "Preset: " + PRESETS[presetIdx];
        statusUntil = System.currentTimeMillis() + 2500;
    }

    // ================= drawing =================
    @Override
    public void extractRenderState(GuiGraphicsExtractor g, int mouseX, int mouseY, float delta) {
        hits.clear();
        frameG = g;
        mx = mouseX; my = mouseY;
        for (EditBox b : boxes.values()) { b.setX(-200); b.setY(-200); }

        g.fill(0, 0, width, height, 0xB0000000);
        g.fillGradient(0, 0, width, height / 3, 0x50000000, 0x00000000);
        winW = Math.min(width - 12, Math.max(430, (int) (width * 0.6f)));
        winX = (width - winW) / 2;
        winY = 8;
        winH = Math.max(60, height - 8 - 22);   // leave room for the bottom logo + version
        GlassUi.panel(g, winX, winY, winW, winH, 7);

        gridTop = top(g, false);
        gridBottom = winY + winH - 5;
        gridLeft = winX + 5;
        gridRight = winX + winW - 9;

        drawGrid(g);
        // cover any card overflow, then draw the real header on top
        g.fillGradient(winX + 3, winY + 1, winX + winW - 3, gridTop,
                GlassUi.panelTint(0f), GlassUi.panelTint((gridTop - winY) / (float) winH));
        g.fillGradient(winX + 3, gridBottom, winX + winW - 3, winY + winH - 1,
                GlassUi.panelTint((gridBottom - winY) / (float) winH), GlassUi.panelTint(1f));
        top(g, true);

        // slide-in settings panel
        float target = sel != null ? 1f : 0f;
        anim += (target - anim) * 0.25f;
        if (Math.abs(target - anim) < 0.01f) anim = target;
        if (anim > 0f) drawPanel(g);

        super.extractRenderState(g, mouseX, mouseY, delta);
    }

    private void gridHit(int x, int y, int w, int h, Runnable r) {
        int y1 = Math.max(y, gridTop), y2 = Math.min(y + h, gridBottom);
        if (y2 > y1) hits.add(new Hit(x, y1, w, y2 - y1, r, 1));
    }

    private void drawGrid(GuiGraphicsExtractor g) {
        List<ModEntry> list = filtered();
        int gap = 4, ch = 58;
        int cols = Math.max(2, Math.min(6, (gridRight - gridLeft + gap) / 92));
        int cw = (gridRight - gridLeft - (cols - 1) * gap) / cols;
        int rows = (list.size() + cols - 1) / cols;
        int content = rows * (ch + gap) - gap;
        maxG = Math.max(0, content - (gridBottom - gridTop));
        scrollG = Math.max(0, Math.min(maxG, scrollG));
        boolean blocked = anim > 0.5f;

        for (int i = 0; i < list.size(); i++) {
            final ModEntry e = list.get(i);
            int cx = gridLeft + (i % cols) * (cw + gap);
            int y = gridTop + (i / cols) * (ch + gap) - Math.round(scrollG);
            if (y + ch <= gridTop || y >= gridBottom) continue;

            boolean hov = !blocked && in(mx, my, cx, Math.max(y, gridTop), cw, Math.min(ch, gridBottom - Math.max(y, gridTop)));
            boolean on = e.enabled();
            GlassUi.card(g, cx, y, cw, ch, hov, e == sel, on);
            g.text(font, fit(e.name, cw - 8), cx + 6, y + 6, GlassUi.TEXT, false);
            GlassUi.icon(g, e.id, cx + cw / 2 - 11, y + 17, 22, on);

            int by = y + ch - 17;
            boolean hg = in(mx, my, cx + 5, by, 14, 12), hb = in(mx, my, cx + 22, by, cw - 27, 12);
            GlassUi.button(g, cx + 5, by, 14, 12, hg, e == sel);
            GlassUi.icon(g, "ui_gear", cx + 8, by + 2, 8, true);
            GlassUi.enabledButton(g, font, cx + 22, by, cw - 27, 12, hb, on);

            gridHit(cx, y, cw, ch, () -> select(e));
            gridHit(cx + 5, by, 14, 12, () -> select(e));
            gridHit(cx + 22, by, cw - 27, 12, () -> e.setEnabled(!e.enabled()));
        }
        if (list.isEmpty()) {
            String t = "No modules found";
            g.text(font, t, (gridLeft + gridRight) / 2 - font.width(t) / 2, gridTop + 20, GlassUi.DIM, false);
        }
        if (maxG > 0) {
            int trackH = gridBottom - gridTop;
            int thumb = Math.max(14, trackH * trackH / (trackH + maxG));
            int ty = gridTop + (int) ((trackH - thumb) * (scrollG / (float) maxG));
            GlassUi.round(g, winX + winW - 7, gridTop, 3, gridBottom - gridTop, 1, 0xFF1C1019);
            GlassUi.round(g, winX + winW - 7, ty, 3, thumb, 1, GlassUi.ACCENT);
        }
    }

    private void drawPanel(GuiGraphicsExtractor g) {
        panelW = (int) Math.min(190, winW * 0.55f);
        int right = winX + winW - 5;
        panelX = right - Math.round(panelW * anim);
        int pw = right - panelX;
        GlassUi.panel(g, panelX, gridTop, pw, gridBottom - gridTop, 6);
        GlassUi.rim(g, panelX, gridTop, pw, gridBottom - gridTop, 6, 0x90E0344F, 0x40E0344F);
        hits.add(new Hit(panelX, gridTop, pw, gridBottom - gridTop, () -> {}, 2));   // blocks clicks on cards below
        if (sel == null) return;

        g.text(font, fit(sel.name, panelW - 30), panelX + 6, gridTop + 5, 0xFFFFFFFF, true);
        boolean hc = in(mx, my, right - 15, gridTop + 3, 12, 12);
        GlassUi.button(g, right - 15, gridTop + 3, 12, 12, hc, false);
        GlassUi.icon(g, "ui_close", right - 12, gridTop + 6, 6, true);
        hits.add(new Hit(right - 15, gridTop + 3, 12, 12, this::closePanel, 0));

        begin(panelX + 5, Math.max(10, pw - 10), gridTop + 18, gridBottom - 3, scrollS);
        toggle("Enabled", sel.enabled(), () -> sel.setEnabled(!sel.enabled()));
        sel.settings(this);
        maxS = end(scrollS);
        scrollS = Math.max(0, Math.min(maxS, scrollS));
    }

    // ================= SettingsUi =================
    private void begin(int x, int w, int top, int bottom, float scroll) {
        rowX = x; rowW = w; viewTop = top; viewBottom = bottom;
        cy = top - Math.round(scroll);
    }

    private int end(float scroll) {
        int content = cy + Math.round(scroll) - viewTop;
        return Math.max(0, content - (viewBottom - viewTop));
    }

    private boolean vis() { return cy >= viewTop && cy + RH <= viewBottom; }

    private void rowHit(Runnable r) { hits.add(new Hit(rowX, cy, rowW, RH - 1, r, 2)); }

    @Override
    public void header(String t) {
        if (vis()) g().text(font, t, rowX + 2, cy + 3, GlassUi.PURPLE_LIGHT, false);
        cy += RH;
    }

    @Override
    public void note(String text) {
        String[] words = text.split(" ");
        StringBuilder line = new StringBuilder();
        List<String> lines = new ArrayList<>();
        for (String w : words) {
            String t = line.length() == 0 ? w : line + " " + w;
            if (font.width(t) > rowW - 6 && line.length() > 0) { lines.add(line.toString()); line = new StringBuilder(w); }
            else line = new StringBuilder(t);
        }
        if (line.length() > 0) lines.add(line.toString());
        for (String l : lines) {
            if (cy >= viewTop && cy + 10 <= viewBottom) g().text(font, l, rowX + 3, cy + 1, GlassUi.DIM, false);
            cy += 10;
        }
        cy += 4;
    }

    @Override
    public void toggle(String label, boolean on, Runnable flip) {
        if (vis()) {
            boolean hov = in(mx, my, rowX, cy, rowW, RH - 1);
            GlassUi.card(g(), rowX, cy, rowW, RH - 1, hov, false);
            g().text(font, label, rowX + 5, cy + 3, GlassUi.TEXT, false);
            GlassUi.toggle(g(), rowX + rowW - 24, cy + 2, on);
            rowHit(flip);
        }
        cy += RH;
    }

    @Override
    public void cycle(String label, String value, Runnable next) {
        if (vis()) {
            boolean hov = in(mx, my, rowX, cy, rowW, RH - 1);
            GlassUi.card(g(), rowX, cy, rowW, RH - 1, hov, false);
            g().text(font, label, rowX + 5, cy + 3, GlassUi.TEXT, false);
            String v = fit(value, Math.max(20, rowW - 14 - font.width(label)));
            g().text(font, v, rowX + rowW - 5 - font.width(v), cy + 3, GlassUi.PURPLE_LIGHT, false);
            rowHit(next);
        }
        cy += RH;
    }

    @Override
    public void stepper(String label, String value, Runnable minus, Runnable plus) {
        if (vis()) {
            GlassUi.card(g(), rowX, cy, rowW, RH - 1, false, false);
            g().text(font, label, rowX + 5, cy + 3, GlassUi.TEXT, false);
            int bx = rowX + rowW - 56, px = rowX + rowW - 16;
            boolean h1 = in(mx, my, bx, cy + 1, 12, 11), h2 = in(mx, my, px, cy + 1, 12, 11);
            GlassUi.button(g(), bx, cy + 1, 12, 11, h1, false);
            GlassUi.button(g(), px, cy + 1, 12, 11, h2, false);
            g().text(font, "-", bx + 4, cy + 3, 0xFFFFFFFF, false);
            g().text(font, "+", px + 4, cy + 3, 0xFFFFFFFF, false);
            g().text(font, value, bx + 12 + (px - bx - 12 - font.width(value)) / 2, cy + 3, GlassUi.PURPLE_LIGHT, false);
            hits.add(new Hit(bx, cy + 1, 12, 11, minus, 2));
            hits.add(new Hit(px, cy + 1, 12, 11, plus, 2));
        }
        cy += RH;
    }

    @Override
    public void hex(String key, String label, String value, Consumer<String> onValid) {
        EditBox b = boxes.get(key);
        if (b == null) {
            b = new EditBox(font, -200, -200, 54, 12, Component.literal(label));
            b.setMaxLength(9);
            b.setValue(value);
            b.setResponder(v -> { if (ColorUtil.isValid(v)) onValid.accept(v); });
            boxes.put(key, b);
            addRenderableWidget(b);
        }
        if (vis()) {
            GlassUi.card(g(), rowX, cy, rowW, RH - 1, false, false);
            g().text(font, label, rowX + 5, cy + 3, GlassUi.TEXT, false);
            b.setX(rowX + rowW - 58);
            b.setY(cy + 1);
        }
        cy += RH;
    }

    // the graphics object of the frame being drawn
    private GuiGraphicsExtractor frameG;
    private GuiGraphicsExtractor g() { return frameG; }

    // ================= input =================
    @Override
    public boolean mouseClicked(MouseButtonEvent e, boolean dbl) {
        if (super.mouseClicked(e, dbl)) return true;
        int x = (int) e.x(), y = (int) e.y();
        pending = null; dragged = false; pressX = x; pressY = y; dragRegion = 0;
        for (int i = hits.size() - 1; i >= 0; i--) {
            Hit h = hits.get(i);
            if (!in(x, y, h.x(), h.y(), h.w(), h.h())) continue;
            if (h.region() == 0) { h.run().run(); return true; }
            pending = h;
            dragRegion = h.region();
            return true;
        }
        if (anim > 0.5f && in(x, y, panelX, gridTop, winX + winW - 5 - panelX, gridBottom - gridTop)) dragRegion = 2;
        else if (in(x, y, gridLeft, gridTop, gridRight - gridLeft, gridBottom - gridTop)) dragRegion = 1;
        return dragRegion != 0;
    }

    @Override
    public boolean mouseDragged(MouseButtonEvent e, double dx, double dy) {
        if (dragRegion != 0) {
            if (!dragged && (Math.abs(e.x() - pressX) > 3 || Math.abs(e.y() - pressY) > 3)) dragged = true;
            if (dragged) {
                if (dragRegion == 1) scrollG = Math.max(0, Math.min(maxG, scrollG - (float) dy));
                else scrollS = Math.max(0, Math.min(maxS, scrollS - (float) dy));
            }
            return true;
        }
        return super.mouseDragged(e, dx, dy);
    }

    @Override
    public boolean mouseReleased(MouseButtonEvent e) {
        if (pending != null && !dragged) pending.run().run();
        pending = null;
        dragRegion = 0;
        return super.mouseReleased(e);
    }

    @Override
    public boolean mouseScrolled(double x, double y, double sx, double sy) {
        float step = (float) (-sy * 18);
        if (anim > 0.5f && in((int) x, (int) y, panelX, gridTop, winX + winW - 5 - panelX, gridBottom - gridTop)) {
            scrollS = Math.max(0, Math.min(maxS, scrollS + step));
            return true;
        }
        scrollG = Math.max(0, Math.min(maxG, scrollG + step));
        return true;
    }

    @Override
    public boolean keyPressed(KeyEvent e) {
        if (e.key() == 344) {                       // Right Shift closes, unless you are typing
            boolean typing = search != null && search.isFocused();
            for (EditBox b : boxes.values()) if (b.isFocused()) typing = true;
            if (!typing) { onClose(); return true; }
        }
        return super.keyPressed(e);
    }

    @Override
    public void onClose() {
        EclipseConfig.save();
        minecraft.setScreen(parent);
    }
}
