package dev.eclipse.client.hud;

import dev.eclipse.client.config.EclipseConfig;
import dev.eclipse.client.util.ColorUtil;
import net.minecraft.client.gui.GuiGraphicsExtractor;

/**
 * Fog Overlay: a coloured haze over the screen (full tint, soft vignette edges, or both) with optional
 * breathing pulse. It is drawn on the HUD layer, so it tints what you see but does not change world fog.
 */
public final class FogOverlay {
    private FogOverlay() {}

    public static void render(GuiGraphicsExtractor g, int w, int h) {
        EclipseConfig c = EclipseConfig.get();
        if (!c.fogEnabled) return;
        int rgb = ColorUtil.parse(c.fogColor, 0xFFE0344F) & 0x00FFFFFF;
        float op = Math.max(0, Math.min(100, c.fogOpacity)) / 100f;
        if (c.fogPulse) {
            double t = System.currentTimeMillis() / 1000.0 * (0.2 + 0.2 * Math.max(1, Math.min(10, c.fogPulseSpeed)));
            op *= 0.6f + 0.4f * (float) Math.sin(t * Math.PI * 2);
        }
        op = Math.max(0f, Math.min(1f, op));
        boolean tint = !c.fogMode.equals("vignette");
        boolean vig = !c.fogMode.equals("tint");
        if (tint) {
            int a = (int) (op * (vig ? 0.35f : 0.8f) * 255);
            if (a > 0) g.fill(0, 0, w, h, (a << 24) | rgb);
        }
        if (vig) {
            int edge = Math.max(8, (int) (Math.min(w, h) * Math.max(10, Math.min(60, c.fogEdge)) / 100f));
            int steps = 14;
            for (int i = 0; i < steps; i++) {
                float k = 1f - i / (float) steps;               // strongest at the very edge
                int a = (int) (op * k * k * 255);
                if (a <= 0) continue;
                int col = (a << 24) | rgb;
                int y0 = edge * i / steps, y1 = edge * (i + 1) / steps;
                g.fill(0, y0, w, y1, col);                       // top
                g.fill(0, h - y1, w, h - y0, col);               // bottom
                g.fill(y0, y1, y1, h - y1, col);                 // left
                g.fill(w - y1, y1, w - y0, h - y1, col);         // right
            }
        }
    }
}
