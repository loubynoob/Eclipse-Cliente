package dev.eclipse.client.hud;

import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.item.PrimedTnt;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** Countdown for lit TNT near you (within 32 blocks). */
public class TntHud extends HudModule {
    public TntHud() { super("tnt", "TNT Timer", "PvP", 0.5f, 0.3f); }

    @Override
    public List<Option> options() {
        return List.of(new Option("max", "Max shown", new String[]{"3", "1", "5"}));
    }

    @Override
    protected List<String> lines(Minecraft mc, boolean preview) {
        List<String> out = new ArrayList<>();
        if (preview || mc.player == null || mc.level == null) {
            out.add("TNT 2.4s (6m)");
            out.add("TNT 3.8s (9m)");
            return out;
        }
        int max = Integer.parseInt(opt("max", "3"));
        List<Entity> list = new ArrayList<>(mc.level.getEntities((Entity) null, mc.player.getBoundingBox().inflate(32.0)));
        list.sort((a, b) -> Float.compare(a.distanceTo(mc.player), b.distanceTo(mc.player)));
        for (Entity e : list) {
            if (e instanceof PrimedTnt t) {
                out.add(String.format(Locale.ROOT, "TNT %.1fs (%dm)", t.getFuse() / 20.0, Math.round(e.distanceTo(mc.player))));
                if (out.size() >= max) break;
            }
        }
        return out;
    }

    @Override
    protected void drawContent(net.minecraft.client.gui.GuiGraphicsExtractor g, Minecraft mc, boolean preview) {
        if (lines(mc, preview).isEmpty()) return; // no TNT lit: draw nothing
        super.drawContent(g, mc, preview);
    }
}
