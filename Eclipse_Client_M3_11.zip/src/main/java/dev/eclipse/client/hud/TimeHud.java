package dev.eclipse.client.hud;

import net.minecraft.client.Minecraft;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

/** Your real-world clock. */
public class TimeHud extends HudModule {
    public TimeHud() { super("realtime", "Real Time", "Survival", 0.01f, 0.50f); }

    @Override
    public List<Option> options() {
        return List.of(
                new Option("format", "Format", new String[]{"24h", "12h"}),
                new Option("seconds", "Seconds", new String[]{"off", "on"}));
    }

    @Override
    protected List<String> lines(Minecraft mc, boolean preview) {
        boolean h12 = opt("format", "24h").equals("12h"), sec = optOn("seconds", false);
        String p = (h12 ? "hh" : "HH") + ":mm" + (sec ? ":ss" : "") + (h12 ? " a" : "");
        return List.of(LocalTime.now().format(DateTimeFormatter.ofPattern(p, java.util.Locale.ENGLISH)));
    }
}
