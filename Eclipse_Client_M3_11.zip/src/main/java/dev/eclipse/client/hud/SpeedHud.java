package dev.eclipse.client.hud;

import net.minecraft.client.Minecraft;
import java.util.List;
import java.util.Locale;

/** How fast you are moving (measured from your position every tick). */
public class SpeedHud extends HudModule {
    private static double lastX, lastY, lastZ, horiz, total;
    private static boolean have;

    public SpeedHud() { super("speed", "Speed", "PvP", 0.01f, 0.32f); }

    /** Called every client tick. */
    public static void tick(Minecraft mc) {
        if (mc.player == null) { have = false; horiz = total = 0; return; }
        double x = mc.player.getX(), y = mc.player.getY(), z = mc.player.getZ();
        if (have) {
            double dx = x - lastX, dy = y - lastY, dz = z - lastZ;
            horiz = Math.sqrt(dx * dx + dz * dz) * 20.0;
            total = Math.sqrt(dx * dx + dy * dy + dz * dz) * 20.0;
        }
        lastX = x; lastY = y; lastZ = z; have = true;
    }

    @Override
    public List<Option> options() {
        return List.of(
                new Option("unit", "Unit", new String[]{"blocks/s", "km/h"}),
                new Option("axis", "Measure", new String[]{"horizontal", "total"}),
                new Option("decimals", "Decimals", new String[]{"1", "0", "2"}));
    }

    @Override
    protected List<String> lines(Minecraft mc, boolean preview) {
        double v = preview ? 5.6 : (opt("axis", "horizontal").equals("total") ? total : horiz);
        boolean kmh = opt("unit", "blocks/s").equals("km/h");
        if (kmh) v *= 3.6;
        String f = "%." + Integer.parseInt(opt("decimals", "1")) + "f";
        return List.of("Speed: " + String.format(Locale.ROOT, f, v) + (kmh ? " km/h" : " b/s"));
    }
}
