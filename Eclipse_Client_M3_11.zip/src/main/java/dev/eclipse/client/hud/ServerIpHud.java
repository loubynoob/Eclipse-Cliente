package dev.eclipse.client.hud;

import net.minecraft.client.Minecraft;
import java.util.List;

/** The address of the server you are on. */
public class ServerIpHud extends HudModule {
    public ServerIpHud() { super("serverip", "Server IP", "Survival", 0.5f, 0.02f); }

    @Override
    protected List<String> lines(Minecraft mc, boolean preview) {
        if (preview) return List.of("play.example.net");
        var sd = mc.getCurrentServer();
        return List.of(sd == null ? "Singleplayer" : sd.ip);
    }
}
