package dev.eclipse.client.hud;

import dev.eclipse.client.util.ColorUtil;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;

import java.util.ArrayList;
import java.util.List;

/** Active potion effects: name, level and time left. Fully configurable in the editor. */
public class PotionHud extends HudModule {
    private record Entry(String text, int color) {}

    private static final String[] ROMAN = {"", "I", "II", "III", "IV", "V", "VI", "VII", "VIII", "IX", "X"};

    public PotionHud() { super("potions", "Potions", "PvP", 0.97f, 0.05f); }

    @Override
    public List<Option> options() {
        return List.of(
                new Option("time", "Show time", new String[]{"on", "off"}),
                new Option("level", "Level", new String[]{"roman", "number", "off"}),
                new Option("show", "Show effects", new String[]{"all", "good", "bad"}),
                new Option("color", "Colors", new String[]{"effect", "custom"}),
                new Option("warn", "Red when low", new String[]{"on", "off"}),
                new Option("max", "Max shown", new String[]{"6", "3", "10"}));
    }

    private String level(int amp) {
        int lvl = amp + 1;
        return switch (opt("level", "roman")) {
            case "off" -> "";
            case "number" -> " " + lvl;
            default -> lvl < ROMAN.length ? " " + ROMAN[lvl] : " " + lvl;
        };
    }

    private static String time(int ticks) {
        if (ticks < 0) return "**:**"; // infinite
        int sec = ticks / 20;
        return String.format("%d:%02d", sec / 60, sec % 60);
    }

    private int pick(int effectColor, int ticks) {
        if (optOn("warn", true) && ticks >= 0 && ticks < 200) return 0xFFFF5555; // under 10 s
        if (opt("color", "effect").equals("custom")) return textColor();
        return 0xFF000000 | (effectColor & 0xFFFFFF);
    }

    private List<Entry> entries(Minecraft mc, boolean preview) {
        List<Entry> out = new ArrayList<>();
        boolean showTime = optOn("time", true);
        if (preview || mc.player == null) {
            out.add(new Entry("Speed" + level(1) + (showTime ? "  1:30" : ""), pick(0x7CAFC6, 1800)));
            out.add(new Entry("Strength" + level(0) + (showTime ? "  0:45" : ""), pick(0x932423, 900)));
            out.add(new Entry("Regeneration" + level(1) + (showTime ? "  0:08" : ""), pick(0xCD5CAB, 160)));
            return out;
        }
        int max = Integer.parseInt(opt("max", "6"));
        String show = opt("show", "all");
        for (var inst : mc.player.getActiveEffects()) {
            var eff = inst.getEffect();
            if (dev.eclipse.client.config.EclipseConfig.get().fullbright && eff.equals(net.minecraft.world.effect.MobEffects.NIGHT_VISION)) continue; // Eclipse Fullbright, not a real potion
            boolean good = eff.value().isBeneficial();
            if (show.equals("good") && !good) continue;
            if (show.equals("bad") && good) continue;
            int d = inst.getDuration();
            String name = eff.value().getDisplayName().getString();
            out.add(new Entry(name + level(inst.getAmplifier()) + (showTime ? "  " + time(d) : ""),
                    pick(eff.value().getColor(), d)));
            if (out.size() >= max) break;
        }
        return out;
    }

    @Override
    protected List<String> lines(Minecraft mc, boolean preview) {
        List<String> l = new ArrayList<>();
        for (Entry e : entries(mc, preview)) l.add(e.text());
        return l;
    }

    @Override
    protected void drawContent(GuiGraphicsExtractor g, Minecraft mc, boolean preview) {
        List<Entry> es = entries(mc, preview);
        if (es.isEmpty()) return; // no effects: draw nothing, not an empty box
        int w = contentWidth(mc, preview), h = contentHeight(mc, preview);
        if (s.background) g.fill(0, 0, w, h, bgColor());
        int y = 3;
        for (Entry e : es) {
            g.text(mc.font, e.text(), 3, y, e.color(), s.shadow);
            y += mc.font.lineHeight + 1;
        }
    }
}
