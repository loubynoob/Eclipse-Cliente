package dev.eclipse.client.hud;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;

import java.util.List;

/**
 * Movement state HUD, e.g. "[Sprinting (Toggled)]", "[Crouching]", "[Flying (Spectator)]".
 * Every part is configurable in the HUD editor (what to show, names, brackets, suffix, colors).
 */
public class MovementHud extends HudModule {
    private static final int NONE = 0, SPRINT = 1, CROUCH = 2, FLY = 3;
    private int kind = SPRINT; // state shown last frame, used to pick the color

    public MovementHud() { super("movement", "Movement", "PvP", 0.02f, 0.45f); }

    @Override
    public List<Option> options() {
        return List.of(
                new Option("sprint", "Show sprinting", new String[]{"on", "off"}),
                new Option("crouch", "Show crouching", new String[]{"on", "off"}),
                new Option("fly", "Show flying/spectator", new String[]{"on", "off"}),
                new Option("brackets", "Brackets", new String[]{"[ ]", "( )", "none"}),
                new Option("suffix", "Toggled/Held text", new String[]{"on", "off"}),
                new Option("names", "Names", new String[]{"full", "short"}),
                new Option("color", "Colors", new String[]{"auto", "custom"}));
    }

    private String name(int k) {
        boolean full = opt("names", "full").equals("full");
        return switch (k) {
            case SPRINT -> full ? "Sprinting" : "Sprint";
            case CROUCH -> full ? "Crouching" : "Sneak";
            default -> full ? "Flying" : "Fly";
        };
    }

    private String wrap(String s) {
        return switch (opt("brackets", "[ ]")) {
            case "( )" -> "(" + s + ")";
            case "none" -> s;
            default -> "[" + s + "]";
        };
    }

    /** Returns the text for the current state, or null if nothing should be shown. */
    private String state(Minecraft mc, boolean preview) {
        if (preview || mc.player == null) {
            kind = SPRINT;
            return wrap(name(SPRINT) + (optOn("suffix", true) ? " (Toggled)" : ""));
        }
        var p = mc.player;
        if (optOn("fly", true)) {
            if (p.isSpectator()) { kind = FLY; return wrap(name(FLY) + " (Spectator)"); }
            if (p.getAbilities().flying) { kind = FLY; return wrap(name(FLY)); }
        }
        if (optOn("crouch", true) && p.isCrouching()) { kind = CROUCH; return wrap(name(CROUCH)); }
        if (optOn("sprint", true) && p.isSprinting()) {
            kind = SPRINT;
            String suffix = "";
            if (optOn("suffix", true)) suffix = mc.options.toggleSprint().get() ? " (Toggled)" : " (Held)";
            return wrap(name(SPRINT) + suffix);
        }
        kind = NONE;
        return null;
    }

    @Override
    protected int textColor() {
        if (opt("color", "auto").equals("custom")) return super.textColor();
        return switch (kind) {
            case CROUCH -> 0xFFFFE066; // yellow
            case FLY -> 0xFF66E0FF;    // cyan
            default -> 0xFF7CFF7C;     // green
        };
    }

    @Override
    protected List<String> lines(Minecraft mc, boolean preview) {
        String s = state(mc, preview);
        return s == null ? List.of() : List.of(s);
    }

    @Override
    protected void drawContent(GuiGraphicsExtractor g, Minecraft mc, boolean preview) {
        if (lines(mc, preview).isEmpty()) return; // nothing to show: draw nothing, not an empty box
        super.drawContent(g, mc, preview);
    }
}
