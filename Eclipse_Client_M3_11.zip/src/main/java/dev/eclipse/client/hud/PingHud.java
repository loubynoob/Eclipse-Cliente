package dev.eclipse.client.hud;

import net.minecraft.client.Minecraft;
import java.util.List;

/** Your connection latency to the server. */
public class PingHud extends HudModule {
    private int lastPing;

    public PingHud() { super("ping", "Ping", "PvP", 0.01f, 0.26f); }

    @Override
    public List<Option> options() {
        return List.of(
                new Option("color", "Colors", new String[]{"auto", "custom"}),
                new Option("label", "Label", new String[]{"Ping: 42 ms", "42 ms", "42"}));
    }

    private int ping(Minecraft mc, boolean preview) {
        if (preview || mc.player == null || mc.getConnection() == null) return 42;
        var info = mc.getConnection().getPlayerInfo(mc.player.getUUID());
        return info == null ? 0 : info.getLatency();
    }

    @Override
    protected int textColor() {
        if (opt("color", "auto").equals("custom")) return super.textColor();
        return lastPing < 80 ? 0xFF7CFF7C : lastPing < 150 ? 0xFFFFE066 : 0xFFFF5555;
    }

    @Override
    protected List<String> lines(Minecraft mc, boolean preview) {
        lastPing = ping(mc, preview);
        return List.of(switch (opt("label", "Ping: 42 ms")) {
            case "42 ms" -> lastPing + " ms";
            case "42" -> String.valueOf(lastPing);
            default -> "Ping: " + lastPing + " ms";
        });
    }
}
