package dev.eclipse.client.hud;

import net.minecraft.client.Minecraft;
import java.util.List;

/** How many players are online (tab list size). */
public class PlayersHud extends HudModule {
    public PlayersHud() { super("players", "Players", "Survival", 0.01f, 0.62f); }

    @Override
    protected List<String> lines(Minecraft mc, boolean preview) {
        int n = 12;
        if (!preview) n = mc.getConnection() == null ? 1 : mc.getConnection().getOnlinePlayers().size();
        return List.of("Players: " + n);
    }
}
