package dev.eclipse.client.hud;

import net.minecraft.client.Minecraft;
import net.minecraft.world.item.ItemStack;
import java.util.ArrayList;
import java.util.List;

/** The item in your hand: name plus durability left or stack size. */
public class HeldItemHud extends HudModule {
    public HeldItemHud() { super("helditem", "Held Item", "Survival", 0.5f, 0.82f); }

    @Override
    public List<Option> options() {
        return List.of(
                new Option("name", "Item name", new String[]{"on", "off"}),
                new Option("detail", "Durability / count", new String[]{"on", "off"}));
    }

    @Override
    protected List<String> lines(Minecraft mc, boolean preview) {
        List<String> out = new ArrayList<>();
        if (preview || mc.player == null) {
            if (optOn("name", true)) out.add("Diamond Pickaxe");
            if (optOn("detail", true)) out.add("1201 / 1561");
            return out;
        }
        ItemStack st = mc.player.getMainHandItem();
        if (st.isEmpty()) return out;
        if (optOn("name", true)) out.add(st.getHoverName().getString());
        if (optOn("detail", true)) {
            if (st.isDamageableItem()) out.add((st.getMaxDamage() - st.getDamageValue()) + " / " + st.getMaxDamage());
            else if (st.getCount() > 1) out.add("x" + st.getCount());
        }
        return out;
    }

    @Override
    protected void drawContent(net.minecraft.client.gui.GuiGraphicsExtractor g, Minecraft mc, boolean preview) {
        if (lines(mc, preview).isEmpty()) return; // empty hand: draw nothing
        super.drawContent(g, mc, preview);
    }
}
