package dev.eclipse.client.hud;

import net.minecraft.client.Minecraft;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import java.util.List;

/** How many arrows are in your inventory. */
public class ArrowHud extends HudModule {
    public ArrowHud() { super("arrows", "Arrows", "PvP", 0.01f, 0.38f); }

    @Override
    public List<Option> options() {
        return List.of(new Option("label", "Label", new String[]{"Arrows: 64", "64"}));
    }

    @Override
    protected List<String> lines(Minecraft mc, boolean preview) {
        int n = 64;
        if (!preview && mc.player != null) {
            n = 0;
            var inv = mc.player.getInventory();
            for (int i = 0; i < inv.getContainerSize(); i++) {
                ItemStack st = inv.getItem(i);
                if (st.is(Items.ARROW)) n += st.getCount();
            }
        }
        return List.of(opt("label", "Arrows: 64").equals("64") ? String.valueOf(n) : "Arrows: " + n);
    }
}
