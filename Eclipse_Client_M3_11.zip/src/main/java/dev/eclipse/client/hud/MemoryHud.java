package dev.eclipse.client.hud;

import net.minecraft.client.Minecraft;
import java.util.List;

/** Java memory in use. */
public class MemoryHud extends HudModule {
    public MemoryHud() { super("memory", "Memory", "PvP", 0.01f, 0.44f); }

    @Override
    public List<Option> options() {
        return List.of(new Option("mode", "Show", new String[]{"percent", "used / max"}));
    }

    @Override
    protected List<String> lines(Minecraft mc, boolean preview) {
        Runtime r = Runtime.getRuntime();
        long max = r.maxMemory() >> 20, used = (r.totalMemory() - r.freeMemory()) >> 20;
        if (opt("mode", "percent").equals("percent")) return List.of("Mem: " + (max <= 0 ? 0 : used * 100 / max) + "%");
        return List.of("Mem: " + used + " / " + max + " MB");
    }
}
