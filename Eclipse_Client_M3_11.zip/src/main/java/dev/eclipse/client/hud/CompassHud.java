package dev.eclipse.client.hud;

import net.minecraft.client.Minecraft;
import net.minecraft.util.Mth;
import java.util.List;

/** Which way you are facing, e.g. "NE 45". */
public class CompassHud extends HudModule {
    private static final String[] DIRS = {"N", "NE", "E", "SE", "S", "SW", "W", "NW"};

    public CompassHud() { super("compass", "Compass", "Survival", 0.01f, 0.56f); }

    @Override
    public List<Option> options() {
        return List.of(new Option("degrees", "Degrees", new String[]{"on", "off"}));
    }

    @Override
    protected List<String> lines(Minecraft mc, boolean preview) {
        float yaw = preview || mc.player == null ? 180f : mc.player.getYRot();
        int deg = Math.floorMod(Math.round(Mth.wrapDegrees(yaw + 180f)), 360); // 0 = north
        String dir = DIRS[(deg + 22) / 45 % 8];
        return List.of(optOn("degrees", true) ? dir + " " + deg : dir);
    }
}
