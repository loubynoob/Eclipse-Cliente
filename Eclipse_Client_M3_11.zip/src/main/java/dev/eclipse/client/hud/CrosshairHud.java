package dev.eclipse.client.hud;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;

/** Your own crosshair (drag it anywhere). Optionally hides the vanilla one. */
public class CrosshairHud extends HudModule {
    public CrosshairHud() {
        super("crosshair", "Crosshair", "PvP", 0.5f, 0.5f);
        if (!s.extra.containsKey("init")) { s.enabled = false; s.background = false; s.extra.put("init", "1"); }
    }

    @Override
    public java.util.List<Option> options() {
        return java.util.List.of(
                new Option("style", "Style", new String[]{"cross", "plus", "dot", "square"}),
                new Option("size", "Size", new String[]{"9", "5", "7", "11", "15"}),
                new Option("thick", "Thickness", new String[]{"1", "2", "3"}),
                new Option("gap", "Center gap", new String[]{"0", "1", "2", "3", "4"}));
    }

    private int size() { return Integer.parseInt(opt("size", "9")); }

    @Override public int contentWidth(Minecraft mc, boolean preview) { return size() + 2; }
    @Override public int contentHeight(Minecraft mc, boolean preview) { return size() + 2; }

    @Override
    protected void drawContent(GuiGraphicsExtractor g, Minecraft mc, boolean preview) {
        int n = size(), t = Integer.parseInt(opt("thick", "1")), gap = Integer.parseInt(opt("gap", "1"));
        int c = textColor(), mid = (n + 2) / 2, half = n / 2, ht = t / 2;
        switch (opt("style", "cross")) {
            case "dot" -> g.fill(mid - ht - 1, mid - ht - 1, mid - ht - 1 + t + 2, mid - ht - 1 + t + 2, c);
            case "square" -> g.outline(mid - half, mid - half, n, n, c);
            default -> {
                // four arms around the centre; "plus" also fills the centre dot
                g.fill(mid - ht, mid - half, mid - ht + t, mid - gap, c);              // up
                g.fill(mid - ht, mid + gap + 1, mid - ht + t, mid + half + 1, c);      // down
                g.fill(mid - half, mid - ht, mid - gap, mid - ht + t, c);              // left
                g.fill(mid + gap + 1, mid - ht, mid + half + 1, mid - ht + t, c);      // right
                if (opt("style", "cross").equals("plus")) g.fill(mid - ht, mid - ht, mid - ht + t, mid - ht + t, c);
            }
        }
    }
}
