package dev.eclipse.client.screen;

import dev.eclipse.client.config.EclipseConfig;
import dev.eclipse.client.hud.HudManager;
import dev.eclipse.client.hud.HudModule;
import dev.eclipse.client.util.ColorUtil;
import dev.eclipse.client.util.GlassUi;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;

import java.util.ArrayList;
import java.util.List;

/**
 * Eclipse editor with three tabs:  PvP | Survival | Visuals.
 * PvP: every combat HUD.  Survival: how your Minecraft plays (info HUDs + preferences).
 * Visuals: how your Minecraft looks.  Works from the title screen too (preview mode).
 */
public class HudEditorScreen extends Screen {
    private static final String[] TABS = {"PvP", "Survival", "Visuals"};

    private final Screen parent;
    private int tab;
    private HudModule selected, dragging;
    private int grabX, grabY;
    private EditBox textColor, bgColor, numColor;

    public HudEditorScreen(Screen parent) {
        super(Component.literal("Eclipse"));
        this.parent = parent;
        tab = Math.max(0, Math.min(2, EclipseConfig.get().editorTab));
        selected = firstOfTab();
    }

    /** PvP tab = group "PvP", Survival tab = group "Survival", Visuals has no HUD modules. */
    private static int tabOf(HudModule m) {
        return m.group.equals("Survival") ? 1 : 0;
    }

    private List<HudModule> modulesOfTab() {
        List<HudModule> out = new ArrayList<>();
        for (HudModule m : HudManager.MODULES) if (tab != 2 && tabOf(m) == tab) out.add(m);
        return out;
    }

    private HudModule firstOfTab() {
        List<HudModule> l = modulesOfTab();
        return l.isEmpty() ? null : l.get(0);
    }

    private static String onOff(boolean b) { return b ? "ON" : "OFF"; }

    @Override
    protected void init() {
        clearWidgets();
        textColor = null; bgColor = null; numColor = null;
        EclipseConfig c = EclipseConfig.get();

        // ---- tab bar (top centre) ----
        int tw = 70, tx = width / 2 - (TABS.length * tw + (TABS.length - 1) * 4) / 2;
        for (int i = 0; i < TABS.length; i++) {
            final int idx = i;
            String label = (tab == i ? "> " : "") + TABS[i] + (tab == i ? " <" : "");
            addRenderableWidget(Button.builder(Component.literal(label), b -> {
                tab = idx; c.editorTab = idx; selected = firstOfTab(); init();
            }).bounds(tx + i * (tw + 4), 4, tw, 16).build());
        }

        if (tab == 2) { initVisuals(c); }
        else { initModules(c); }

        addRenderableWidget(Button.builder(Component.literal("Done"), b -> onClose())
                .bounds(width / 2 - 40, height - 22, 80, 18).build());
    }

    // ---------- PvP / Survival ----------
    private void initModules(EclipseConfig c) {
        // module list (left)
        List<HudModule> mods = modulesOfTab();
        boolean two = mods.size() > 6;          // two columns when the list is long (phone screens are short)
        int colW = two ? 64 : 124, step = two ? 15 : 18, bh = two ? 14 : 16;
        int ly = 28;
        for (int i = 0; i < mods.size(); i++) {
            final HudModule mod = mods.get(i);
            String label = (mod == selected ? "> " : "") + mod.name;
            int bx = 8 + (two ? (i % 2) * (colW + 2) : 0);
            int by = 28 + (two ? (i / 2) * step : i * step);
            addRenderableWidget(Button.builder(Component.literal(label), b -> { selected = mod; init(); })
                    .bounds(bx, by, colW, bh).build());
            ly = by + step;
        }
        // preferences under the list
        ly += 6;
        ly = prefButton(ly, "Toggle Sprint: " + onOff(c.toggleSprint), () -> c.toggleSprint = !c.toggleSprint);
        if (tab == 1) {
            ly = prefButton(ly, "FPS Guard: " + onOff(c.fpsGuard), () -> c.fpsGuard = !c.fpsGuard);
            ly = prefButton(ly, "View bobbing: " + c.bobMode, () ->
                    c.bobMode = c.bobMode.equals("vanilla") ? "on" : c.bobMode.equals("on") ? "off" : "vanilla");
            ly = prefButton(ly, "Zoom FOV: " + c.zoomFov, () -> c.zoomFov = c.zoomFov >= 60 ? 30 : c.zoomFov + 10);
            ly = prefButton(ly, "Fullbright: " + onOff(c.fullbright), () -> c.fullbright = !c.fullbright);
            ly = prefButton(ly, "Particles: " + c.particles, () ->
                    c.particles = switch (c.particles) { case "vanilla" -> "all"; case "all" -> "decreased"; case "decreased" -> "minimal"; default -> "vanilla"; });
        }

        if (selected == null) return;

        // module settings (right panel), compact so it fits phone screens
        int px = width - 170, bw = 160, y = 28;
        int third = (bw - 4) / 3;
        addRenderableWidget(Button.builder(Component.literal("HUD: " + onOff(selected.s.enabled)), b -> {
            selected.s.enabled = !selected.s.enabled; init();
        }).bounds(px, y, third, 16).build());
        addRenderableWidget(Button.builder(Component.literal("BG: " + onOff(selected.s.background)), b -> {
            selected.s.background = !selected.s.background; init();
        }).bounds(px + third + 2, y, third, 16).build());
        addRenderableWidget(Button.builder(Component.literal("Shd: " + onOff(selected.s.shadow)), b -> {
            selected.s.shadow = !selected.s.shadow; init();
        }).bounds(px + 2 * (third + 2), y, third, 16).build());
        y += 18;
        addRenderableWidget(Button.builder(Component.literal("-"), b -> { selected.s.scale = Math.max(0.5f, selected.s.scale - 0.1f); }).bounds(px, y, 30, 16).build());
        addRenderableWidget(Button.builder(Component.literal("+"), b -> { selected.s.scale = Math.min(3f, selected.s.scale + 0.1f); }).bounds(px + 130, y, 30, 16).build());
        y += 18;
        int half = (bw - 4) / 2;
        textColor = new EditBox(font, px, y, half, 16, Component.literal("Text #hex"));
        textColor.setMaxLength(9); textColor.setValue(selected.s.textColor);
        textColor.setResponder(v -> { if (ColorUtil.isValid(v)) selected.s.textColor = v; });
        addRenderableWidget(textColor);
        bgColor = new EditBox(font, px + half + 4, y, half, 16, Component.literal("Background #hex"));
        bgColor.setMaxLength(9); bgColor.setValue(selected.s.bgColor);
        bgColor.setResponder(v -> { if (ColorUtil.isValid(v)) selected.s.bgColor = v; });
        addRenderableWidget(bgColor);
        y += 18;
        for (HudModule.Option o : selected.options()) {
            final HudModule.Option opt = o;
            String cur = selected.opt(o.key(), o.choices()[0]);
            addRenderableWidget(Button.builder(Component.literal(o.label() + ": " + cur), b -> {
                String cc = selected.opt(opt.key(), opt.choices()[0]);
                int i = 0;
                for (int k = 0; k < opt.choices().length; k++) if (opt.choices()[k].equals(cc)) i = k;
                selected.s.extra.put(opt.key(), opt.choices()[(i + 1) % opt.choices().length]);
                init();
            }).bounds(px, y, bw, 16).build());
            y += 17;
        }
        if (selected.id.equals("armor")) {
            numColor = new EditBox(font, px, y, bw, 16, Component.literal("Number #hex"));
            numColor.setMaxLength(9); numColor.setValue(selected.opt("numColorHex", "#FFFFFF"));
            numColor.setResponder(v -> { if (ColorUtil.isValid(v)) selected.s.extra.put("numColorHex", v); });
            addRenderableWidget(numColor);
        }
    }

    private int prefButton(int y, String label, Runnable action) {
        addRenderableWidget(Button.builder(Component.literal(label), b -> { action.run(); init(); })
                .bounds(8, y, 132, 16).build());
        return y + 18;
    }

    // ---------- Visuals ----------
    private void initVisuals(EclipseConfig c) {
        int bw = 180, x = width / 2 - bw / 2, y = 34;
        addRenderableWidget(Button.builder(Component.literal("Sky presets..."), b -> minecraft.setScreen(new SkyScreen(this)))
                .bounds(x, y, bw, 18).build()); y += 22;
        addRenderableWidget(Button.builder(Component.literal("Bright inventory: " + onOff(c.brightInventory)), b -> { c.brightInventory = !c.brightInventory; init(); })
                .bounds(x, y, bw, 18).build()); y += 22;
        addRenderableWidget(Button.builder(Component.literal("Logo next to name: " + onOff(c.selfLogo)), b -> { c.selfLogo = !c.selfLogo; init(); })
                .bounds(x, y, bw, 18).build()); y += 22;
        addRenderableWidget(Button.builder(Component.literal("Eclipse title screen: " + onOff(c.eclipseTitle)), b -> { c.eclipseTitle = !c.eclipseTitle; init(); })
                .bounds(x, y, bw, 18).build()); y += 22;
        addRenderableWidget(Button.builder(Component.literal("Eclipse loading screen: " + onOff(c.eclipseLoading)), b -> { c.eclipseLoading = !c.eclipseLoading; init(); })
                .bounds(x, y, bw, 18).build()); y += 22;
        addRenderableWidget(Button.builder(Component.literal("View bobbing: " + c.bobMode), b -> {
            c.bobMode = c.bobMode.equals("vanilla") ? "on" : c.bobMode.equals("on") ? "off" : "vanilla"; init();
        }).bounds(x, y, bw, 18).build());
    }

    @Override
    public void extractRenderState(GuiGraphicsExtractor g, int mouseX, int mouseY, float delta) {
        g.fill(0, 0, width, height, 0x90140A28);
        var mc = minecraft;
        if (tab == 2) {
            GlassUi.panel(g, width / 2 - 100, 26, 200, 150);
            g.text(font, "How your Minecraft looks", width / 2 - 62, height - 38, 0xFFE9D5FF, true);
        } else {
            GlassUi.panel(g, width - 176, 22, 172, height - 46);
            GlassUi.panel(g, 4, 22, 142, height - 46);
            for (HudModule m : modulesOfTab()) {
                m.render(g, mc, true);
                if (m == selected) g.outline(m.lastX - 1, m.lastY - 1, m.lastW + 2, m.lastH + 2, GlassUi.PURPLE);
            }
            String hint = tab == 0 ? "PvP - drag HUDs to move" : "Survival - make it yours";
            g.text(font, hint, width / 2 - font.width(hint) / 2, height - 38, 0xFFE9D5FF, true);
        }
        super.extractRenderState(g, mouseX, mouseY, delta);
    }

    @Override
    public boolean mouseClicked(MouseButtonEvent e, boolean dbl) {
        if (super.mouseClicked(e, dbl)) return true;
        for (HudModule m : modulesOfTab()) {
            if (e.x() >= m.lastX && e.x() <= m.lastX + m.lastW && e.y() >= m.lastY && e.y() <= m.lastY + m.lastH) {
                dragging = m; grabX = (int) e.x() - m.lastX; grabY = (int) e.y() - m.lastY;
                if (selected != m) { selected = m; init(); }
                return true;
            }
        }
        return false;
    }

    @Override
    public boolean mouseDragged(MouseButtonEvent e, double dx, double dy) {
        if (dragging != null) {
            dragging.moveTo(minecraft, (int) e.x() - grabX, (int) e.y() - grabY);
            return true;
        }
        return super.mouseDragged(e, dx, dy);
    }

    @Override
    public boolean mouseReleased(MouseButtonEvent e) {
        dragging = null;
        return super.mouseReleased(e);
    }

    @Override
    public void onClose() {
        EclipseConfig.save();
        minecraft.setScreen(parent);
    }
}
