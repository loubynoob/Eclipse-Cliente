package dev.eclipse.client.mixin;

import dev.eclipse.client.hud.ComboHud;
import net.minecraft.client.multiplayer.MultiPlayerGameMode;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Counts your hits for the Combo HUD. */
@Mixin(MultiPlayerGameMode.class)
public abstract class ComboMixin {
    @Inject(method = "attack", at = @At("HEAD"), require = 0)
    private void eclipse$hit(Player player, Entity target, CallbackInfo ci) {
        ComboHud.onHit();
    }
}
