package dev.eclipse.client.mod;

import java.util.function.Consumer;

/** What a module can put in its settings panel. The Mod Menu implements this. */
public interface SettingsUi {
    void header(String text);
    void note(String text);
    void toggle(String label, boolean on, Runnable flip);
    void cycle(String label, String value, Runnable next);
    void stepper(String label, String value, Runnable minus, Runnable plus);
    /** Hex colour box. {@code key} must be unique inside the module. onValid gets valid colours only. */
    void hex(String key, String label, String value, Consumer<String> onValid);
}
