package dev.eclipse.client.mod;

import dev.eclipse.client.hud.HudModule;

/** One card in the Mod Menu. */
public abstract class ModEntry {
    public final String id, name, category, icon;

    protected ModEntry(String id, String name, String category, String icon) {
        this.id = id;
        this.name = name;
        this.category = category;
        this.icon = icon;
    }

    public abstract boolean enabled();
    public abstract void setEnabled(boolean on);
    public abstract void settings(SettingsUi ui);

    /** The HUD behind this card, or null for non-HUD modules. */
    public HudModule hud() { return null; }

    /** Put this module's settings back to default. */
    public void reset() {}
}
