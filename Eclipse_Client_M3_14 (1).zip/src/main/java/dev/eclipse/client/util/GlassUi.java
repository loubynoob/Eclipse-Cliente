package dev.eclipse.client.util;

import net.minecraft.client.gui.GuiGraphicsExtractor;

/** Flat dark purple-and-black UI pieces used by every Eclipse screen (class name kept for older screens). */
public final class GlassUi {
    private GlassUi() {}

    public static final int PURPLE = 0xFFA855F7;
    public static final int PURPLE_LIGHT = 0xFFD8B4FE;
    public static final int PURPLE_DARK = 0xFF5B21B6;
    public static final int BG = 0xFF0B0B11;
    public static final int PANEL = 0xFF111118;
    public static final int PANEL_HOVER = 0xFF1B1B27;
    public static final int BORDER = 0xFF2A2A3A;
    public static final int TEXT = 0xFFF3EEFF;
    public static final int DIM = 0xFF9A8FBF;

    /** Dark panel with a thin border. */
    public static void panel(GuiGraphicsExtractor g, int x, int y, int w, int h) {
        g.fill(x, y, x + w, y + h, 0xF00B0B11);
        g.outline(x, y, w, h, BORDER);
    }

    /** Dark list/grid card. */
    public static void card(GuiGraphicsExtractor g, int x, int y, int w, int h, boolean hover, boolean selected) {
        g.fill(x, y, x + w, y + h, hover ? PANEL_HOVER : PANEL);
        g.outline(x, y, w, h, selected ? PURPLE : BORDER);
    }

    /** Plain flat button. */
    public static void button(GuiGraphicsExtractor g, int x, int y, int w, int h, boolean hover, boolean on) {
        if (on) {
            g.fillGradient(x, y, x + w, y + h, hover ? 0xFFB57BFF : 0xFFA855F7, hover ? 0xFF6D28D9 : 0xFF5B21B6);
            g.outline(x, y, w, h, PURPLE_LIGHT);
        } else {
            g.fill(x, y, x + w, y + h, hover ? PANEL_HOVER : PANEL);
            g.outline(x, y, w, h, BORDER);
        }
    }

    /** Purple gradient highlight button (like the orange "Store" button, but purple). */
    public static void accent(GuiGraphicsExtractor g, int x, int y, int w, int h, boolean hover) {
        g.fillGradient(x, y, x + w, y + h, hover ? 0xFFB57BFF : 0xFFA855F7, hover ? 0xFF4C1D95 : 0xFF3B1478);
        g.outline(x, y, w, h, PURPLE_LIGHT);
    }

    /** Red button for Quit. */
    public static void danger(GuiGraphicsExtractor g, int x, int y, int w, int h, boolean hover) {
        g.fillGradient(x, y, x + w, y + h, hover ? 0xFFC03A3A : 0xFF9C2A2A, hover ? 0xFF701818 : 0xFF551212);
        g.outline(x, y, w, h, 0xFFE05A5A);
    }

    /** Compatibility alias for older call sites. */
    public static void pill(GuiGraphicsExtractor g, int x, int y, int w, int h, boolean hover, boolean accent) {
        button(g, x, y, w, h, hover, accent);
    }

    /** Small flat on/off switch, 20 x 10. */
    public static void toggle(GuiGraphicsExtractor g, int x, int y, boolean on) {
        g.fill(x, y, x + 20, y + 10, on ? PURPLE_DARK : 0xFF1E1E2A);
        g.outline(x, y, 20, 10, on ? PURPLE : BORDER);
        int kx = on ? x + 11 : x + 1;
        g.fill(kx, y + 1, kx + 8, y + 9, on ? 0xFFFFFFFF : 0xFF6B6485);
    }

    /** "Enabled" / "Disabled" button used on module cards. */
    public static void enabledButton(GuiGraphicsExtractor g, net.minecraft.client.gui.Font font, int x, int y, int w, int h, boolean hover, boolean on) {
        if (on) {
            g.fillGradient(x, y, x + w, y + h, hover ? 0xFF8B3FE8 : 0xFF7C3AED, 0xFF4C1D95);
            g.outline(x, y, w, h, PURPLE);
        } else {
            g.fill(x, y, x + w, y + h, hover ? PANEL_HOVER : 0xFF0E0E15);
            g.outline(x, y, w, h, BORDER);
        }
        String t = on ? "Enabled" : "Disabled";
        g.text(font, t, x + (w - font.width(t)) / 2, y + (h - 8) / 2, on ? 0xFFFFFFFF : DIM, false);
    }

    /** Backwards-compatible helper. */
    public static void segmentBar(GuiGraphicsExtractor g, int x, int y, int w, int h) {
        g.fill(x, y, x + w, y + h, PANEL);
        g.outline(x, y, w, h, BORDER);
    }
}
