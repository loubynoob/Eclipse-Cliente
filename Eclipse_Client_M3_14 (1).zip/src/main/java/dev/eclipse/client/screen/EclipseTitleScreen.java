package dev.eclipse.client.screen;

import com.mojang.realmsclient.RealmsMainScreen;
import dev.eclipse.client.util.Branding;
import dev.eclipse.client.util.GlassUi;
import net.minecraft.ChatFormatting;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.TitleScreen;
import net.minecraft.client.gui.screens.multiplayer.JoinMultiplayerScreen;
import net.minecraft.client.gui.screens.options.OptionsScreen;
import net.minecraft.client.gui.screens.worldselection.SelectWorldScreen;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.network.chat.Component;

import java.util.ArrayList;
import java.util.List;

/**
 * Eclipse main menu in the dark purple style: logo + name, stacked buttons, a highlighted Eclipse Settings
 * button, red Quit, and a small account / options bar in the top-right corner.
 * Layout idea inspired by Fast Client - thanks NoduweyLo.
 */
public class EclipseTitleScreen extends TitleScreen {
    private record Hit(int x, int y, int w, int h, Runnable run) {}

    private final List<Hit> hits = new ArrayList<>();

    public EclipseTitleScreen() { super(); }

    @Override
    protected void init() {
        // deliberately NOT calling super.init(): this screen draws and handles its own buttons
    }

    private static boolean in(int px, int py, int x, int y, int w, int h) {
        return px >= x && px < x + w && py >= y && py < y + h;
    }

    private void flat(GuiGraphicsExtractor g, String label, int x, int y, int w, int h, int mx, int my, Runnable r) {
        boolean hov = in(mx, my, x, y, w, h);
        GlassUi.button(g, x, y, w, h, hov, false);
        g.text(font, label, x + w / 2 - font.width(label) / 2, y + (h - 8) / 2, hov ? 0xFFFFFFFF : GlassUi.TEXT, false);
        hits.add(new Hit(x, y, w, h, r));
    }

    @Override
    public void extractRenderState(GuiGraphicsExtractor g, int mx, int my, float delta) {
        super.extractRenderState(g, mx, my, delta);          // panorama
        hits.clear();
        g.fill(0, 0, width, height, 0xA0000000);             // dark overlay like the reference

        int cx = width / 2;

        // ---- top-right bar: account + quick buttons ----
        String user = minecraft.getUser().getName();
        int ub = font.width(user) + 14, bx = width - 6, by = 6;
        int rw = font.width("Realms") + 10, ow = font.width("Options") + 10;
        bx -= rw; flat(g, "Realms", bx, by, rw, 16, mx, my, () -> minecraft.setScreen(new RealmsMainScreen(this)));
        bx -= ow + 3; flat(g, "Options", bx, by, ow, 16, mx, my,
                () -> minecraft.setScreen(new OptionsScreen(this, minecraft.options, true)));
        bx -= ub + 3;
        g.fill(bx, by, bx + ub, by + 16, GlassUi.PANEL);
        g.outline(bx, by, ub, 16, GlassUi.BORDER);
        g.text(font, user, bx + 7, by + 4, 0xFFFFFFFF, false);

        // ---- logo + name ----
        int bw = 150, bh = 18, gap = 3;
        int total = 34 + 8 + 4 * (bh + gap) + 8 + 18 + 12;
        int y0 = Math.max(26, height / 2 - total / 2);
        Component name = Component.literal("ECLIPSE CLIENT").withStyle(ChatFormatting.BOLD);
        int nw = font.width(name);
        int rowW = 32 + 6 + nw, rx = cx - rowW / 2;
        g.pose().pushMatrix();
        g.pose().translate(rx, y0);
        g.pose().scale(0.5f, 0.5f);
        g.blit(RenderPipelines.GUI_TEXTURED, Branding.LOGO64, 0, 0, 0f, 0f, 64, 64, 64, 64);
        g.pose().popMatrix();
        g.text(font, name, rx + 38, y0 + 12, 0xFFFFFFFF, true);

        // ---- buttons ----
        int y = y0 + 42, x = cx - bw / 2;
        flat(g, "Singleplayer", x, y, bw, bh, mx, my, () -> minecraft.setScreen(new SelectWorldScreen(this)));
        y += bh + gap;
        flat(g, "Multiplayer", x, y, bw, bh, mx, my, () -> minecraft.setScreen(new JoinMultiplayerScreen(this)));
        y += bh + gap;
        flat(g, "Mods", x, y, bw, bh, mx, my, () -> minecraft.setScreen(new ModMenuScreen(this, null)));
        y += bh + gap;
        boolean hs = in(mx, my, x, y, bw, bh);
        GlassUi.accent(g, x, y, bw, bh, hs);
        String es = "Eclipse Settings";
        g.text(font, es, cx - font.width(es) / 2, y + (bh - 8) / 2, 0xFFFFFFFF, true);
        hits.add(new Hit(x, y, bw, bh, () -> minecraft.setScreen(new HudEditorScreen(this))));
        y += bh + gap + 8;

        int qw = 80, qx = cx - qw / 2;
        boolean hq = in(mx, my, qx, y, qw, 18);
        GlassUi.danger(g, qx, y, qw, 18, hq);
        g.text(font, "Quit Game", cx - font.width("Quit Game") / 2, y + 5, 0xFFFFFFFF, false);
        hits.add(new Hit(qx, y, qw, 18, () -> minecraft.stop()));

        String ver = "Eclipse " + Branding.ECLIPSE_BUILD;
        g.text(font, ver, cx - font.width(ver) / 2, y + 24, GlassUi.DIM, false);

        // version line like other screens
        Branding.drawVersion(g, height);
    }

    @Override
    public boolean mouseClicked(MouseButtonEvent e, boolean dbl) {
        int x = (int) e.x(), y = (int) e.y();
        for (int i = hits.size() - 1; i >= 0; i--) {
            Hit h = hits.get(i);
            if (in(x, y, h.x(), h.y(), h.w(), h.h())) { h.run().run(); return true; }
        }
        return super.mouseClicked(e, dbl);
    }
}
