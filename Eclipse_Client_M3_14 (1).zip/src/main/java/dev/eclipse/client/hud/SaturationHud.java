package dev.eclipse.client.hud;

import net.minecraft.client.Minecraft;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** Hunger and saturation numbers. */
public class SaturationHud extends HudModule {
    public SaturationHud() { super("saturation", "Saturation", "Survival", 0.01f, 0.74f); }

    @Override
    public List<Option> options() {
        return List.of(new Option("hunger", "Show hunger", new String[]{"on", "off"}));
    }

    @Override
    protected List<String> lines(Minecraft mc, boolean preview) {
        int food = 20;
        float sat = 5f;
        if (!preview && mc.player != null) {
            food = mc.player.getFoodData().getFoodLevel();
            sat = mc.player.getFoodData().getSaturationLevel();
        }
        List<String> out = new ArrayList<>();
        if (optOn("hunger", true)) out.add("Hunger: " + food);
        out.add("Saturation: " + String.format(Locale.ROOT, "%.1f", sat));
        return out;
    }
}
