package dev.eclipse.client.hud;

import net.minecraft.client.Minecraft;
import java.util.List;

/** Chunk coordinates of the chunk you are in. */
public class ChunkHud extends HudModule {
    public ChunkHud() { super("chunk", "Chunk", "Survival", 0.12f, 0.02f); }

    @Override
    protected List<String> lines(Minecraft mc, boolean preview) {
        int cx = 8, cz = -19;
        if (!preview && mc.player != null) {
            cx = mc.player.blockPosition().getX() >> 4;
            cz = mc.player.blockPosition().getZ() >> 4;
        }
        return List.of("Chunk: " + cx + ", " + cz);
    }
}
