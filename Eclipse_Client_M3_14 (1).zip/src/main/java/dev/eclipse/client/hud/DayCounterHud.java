package dev.eclipse.client.hud;

import net.minecraft.client.Minecraft;
import java.util.List;

/** Which in-game day it is. */
public class DayCounterHud extends HudModule {
    public DayCounterHud() { super("daycounter", "Day Counter", "Survival", 0.01f, 0.80f); }

    @Override
    protected List<String> lines(Minecraft mc, boolean preview) {
        long day = 12;
        if (!preview && mc.level != null) day = mc.level.getOverworldClockTime() / 24000L + 1;
        return List.of("Day " + day);
    }
}
