package dev.eclipse.client.hud;

import net.minecraft.client.Minecraft;
import java.util.List;

/** Name of the biome you are standing in. */
public class BiomeHud extends HudModule {
    public BiomeHud() { super("biome", "Biome", "Survival", 0.01f, 0.68f); }

    @Override
    protected List<String> lines(Minecraft mc, boolean preview) {
        String b = "plains";
        if (!preview && mc.level != null && mc.player != null) {
            b = mc.level.getBiome(mc.player.blockPosition()).unwrapKey()
                    .map(k -> k.identifier().getPath()).orElse("unknown");
        }
        StringBuilder sb = new StringBuilder();
        for (String part : b.split("_")) {
            if (part.isEmpty()) continue;
            if (sb.length() > 0) sb.append(' ');
            sb.append(Character.toUpperCase(part.charAt(0))).append(part.substring(1));
        }
        return List.of("Biome: " + sb);
    }
}
