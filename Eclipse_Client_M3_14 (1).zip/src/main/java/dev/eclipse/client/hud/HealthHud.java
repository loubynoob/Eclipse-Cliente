package dev.eclipse.client.hud;

import dev.eclipse.client.util.ColorUtil;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import java.util.List;
import java.util.Locale;

/** Health as a number (coloured green to red). */
public class HealthHud extends HudModule {
    public HealthHud() { super("health", "Health", "PvP", 0.01f, 0.86f); }

    @Override
    public List<Option> options() {
        return List.of(
                new Option("decimals", "Decimals", new String[]{"0", "1"}),
                new Option("max", "Show max", new String[]{"on", "off"}),
                new Option("color", "Color by health", new String[]{"on", "off"}));
    }

    private float hp(Minecraft mc, boolean preview) { return preview || mc.player == null ? 17f : mc.player.getHealth(); }
    private float maxHp(Minecraft mc, boolean preview) { return preview || mc.player == null ? 20f : mc.player.getMaxHealth(); }

    @Override
    protected List<String> lines(Minecraft mc, boolean preview) {
        String f = opt("decimals", "0").equals("1") ? "%.1f" : "%.0f";
        String t = "Health: " + String.format(Locale.ROOT, f, hp(mc, preview));
        if (opt("max", "on").equals("on")) t += "/" + String.format(Locale.ROOT, "%.0f", maxHp(mc, preview));
        return List.of(t);
    }

    @Override
    protected void drawContent(GuiGraphicsExtractor g, Minecraft mc, boolean preview) {
        List<String> ls = lines(mc, preview);
        int w = contentWidth(mc, preview), h = contentHeight(mc, preview);
        if (s.background) g.fill(0, 0, w, h, bgColor());
        int col = opt("color", "on").equals("on") ? ColorUtil.healthColor(hp(mc, preview) / Math.max(1f, maxHp(mc, preview))) : textColor();
        g.text(mc.font, ls.get(0), 3, 3, col, s.shadow);
    }
}
