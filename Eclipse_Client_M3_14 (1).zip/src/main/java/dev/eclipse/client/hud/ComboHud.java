package dev.eclipse.client.hud;

import net.minecraft.client.Minecraft;
import java.util.List;

/** Hits in a row. Resets when you get hurt or stop hitting for a few seconds. */
public class ComboHud extends HudModule {
    private static int count;
    private static long lastHit;
    private static float lastHealth = -1f;

    public ComboHud() { super("combo", "Combo", "PvP", 0.01f, 0.20f); }

    /** Called from the attack mixin when you hit something. */
    public static void onHit() {
        count++;
        lastHit = System.currentTimeMillis();
    }

    public static void tick(Minecraft mc) {
        if (mc.player == null) { count = 0; lastHealth = -1f; return; }
        float hp = mc.player.getHealth();
        if (lastHealth >= 0f && hp < lastHealth) count = 0;
        lastHealth = hp;
        if (count > 0 && System.currentTimeMillis() - lastHit > 3000L) count = 0;
    }

    @Override
    protected List<String> lines(Minecraft mc, boolean preview) {
        return List.of("Combo: " + (preview ? 3 : count));
    }
}
