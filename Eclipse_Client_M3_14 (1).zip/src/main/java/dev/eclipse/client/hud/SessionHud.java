package dev.eclipse.client.hud;

import net.minecraft.client.Minecraft;
import java.util.List;
import java.util.Locale;

/** How long this play session has been running. */
public class SessionHud extends HudModule {
    private static final long START = System.currentTimeMillis();

    public SessionHud() { super("session", "Session Timer", "Survival", 0.01f, 0.92f); }

    @Override
    protected List<String> lines(Minecraft mc, boolean preview) {
        long sec = (System.currentTimeMillis() - START) / 1000L;
        if (preview) sec = 754;
        String t = sec >= 3600
                ? String.format(Locale.ROOT, "%d:%02d:%02d", sec / 3600, (sec / 60) % 60, sec % 60)
                : String.format(Locale.ROOT, "%02d:%02d", sec / 60, sec % 60);
        return List.of("Session: " + t);
    }
}
