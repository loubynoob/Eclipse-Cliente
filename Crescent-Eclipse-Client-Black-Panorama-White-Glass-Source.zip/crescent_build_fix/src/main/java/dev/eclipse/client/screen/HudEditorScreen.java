package dev.eclipse.client.screen;

import dev.eclipse.client.config.EclipseConfig;
import dev.eclipse.client.hud.HudManager;
import dev.eclipse.client.hud.HudModule;
import dev.eclipse.client.mod.ModRegistry;
import dev.eclipse.client.util.Branding;
import dev.eclipse.client.util.GlassUi;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.network.chat.Component;

import java.util.ArrayList;
import java.util.List;

/**
 * Eclipse HUD editor (opened with Right Shift): every enabled HUD sits on screen, drag it where you want it,
 * right-click it for its options. The big "ECLIPSE SETTINGS" button opens the Mod Menu with all modules.
 * Layout idea inspired by Fast Client - thanks NoduweyLo.
 */
public class HudEditorScreen extends Screen {
    private record Hit(int x, int y, int w, int h, Runnable run) {}

    private final Screen parent;
    private HudModule dragging;
    private int grabX, grabY;
    private boolean snap = false, guides = true;
    private final List<Hit> hits = new ArrayList<>();
    private int mx, my;

    public HudEditorScreen(Screen parent) {
        super(Component.literal("Eclipse"));
        this.parent = parent;
    }

    private static boolean in(int px, int py, int x, int y, int w, int h) {
        return px >= x && px < x + w && py >= y && py < y + h;
    }

    @Override
    public void extractRenderState(GuiGraphicsExtractor g, int mouseX, int mouseY, float delta) {
        hits.clear();
        mx = mouseX; my = mouseY;
        g.fill(0, 0, width, height, 0x78000000);
        g.fillGradient(0, height * 2 / 3, width, height, 0x00000000, 0x60000000);

        // every enabled HUD, with a neutral white box and its name above it
        for (HudModule m : HudManager.MODULES) {
            if (!m.s.enabled) continue;
            m.render(g, minecraft, true);
            boolean hot = m == dragging || in(mx, my, m.lastX, m.lastY, m.lastW, m.lastH);
            g.outline(m.lastX - 1, m.lastY - 1, m.lastW + 2, m.lastH + 2, hot ? GlassUi.PURPLE_LIGHT : GlassUi.PURPLE_DARK);
            int ly = m.lastY >= 11 ? m.lastY - 10 : m.lastY + m.lastH + 2;
            g.text(font, m.name, m.lastX, ly, hot ? 0xFFFFFFFF : GlassUi.DIM, true);
        }

        // alignment guides while dragging
        if (dragging != null && guides) {
            int midX = width / 2, midY = height / 2;
            boolean nearX = Math.abs(dragging.lastX + dragging.lastW / 2 - midX) <= 3;
            boolean nearY = Math.abs(dragging.lastY + dragging.lastH / 2 - midY) <= 3;
            g.fill(midX, 0, midX + 1, height, nearX ? 0xFFFF9AA6 : 0x50E0344F);
            g.fill(0, midY, width, midY + 1, nearY ? 0xFFFF9AA6 : 0x50E0344F);
        }

        // ---- centre block: big logo, Eclipse Settings, Snap / Guides ----
        int cx = width / 2;
        int logo = height < 200 ? 48 : (height < 300 ? 72 : 96);
        int logoY = Math.max(4, height / 2 - (logo + 30));
        g.pose().pushMatrix();
        g.pose().translate(cx - logo / 2f, logoY);
        g.pose().scale(logo / 64f, logo / 64f);
        g.blit(RenderPipelines.GUI_TEXTURED, Branding.LOGO64, 0, 0, 0f, 0f, 64, 64, 64, 64);
        g.pose().popMatrix();

        int bw = 170, bh = 24, bx = cx - bw / 2, by = logoY + logo + 8;
        boolean hov = in(mx, my, bx, by, bw, bh);
        GlassUi.round(g, bx, by, bw, bh, 5, hov ? 0xF02A1621 : 0xE01A0F18, hov ? 0xF01F111A : 0xE0100810);
        GlassUi.round(g, bx + 1, by + 1, bw - 2, bh / 2, 4, 0x18FFFFFF, 0x00FFFFFF);
        GlassUi.round(g, bx, by + 3, 4, bh - 6, 2, GlassUi.ACCENT);
        GlassUi.rim(g, bx, by, bw, bh, 5, hov ? GlassUi.ACCENT_LIGHT : 0x60FFFFFF, hov ? GlassUi.ACCENT : 0x20FFFFFF);
        String t = "ECLIPSE SETTINGS";
        int tstart = cx - (font.width(t) + 16) / 2;
        GlassUi.icon(g, "ui_gear", tstart, by + (bh - 11) / 2, 11, true);
        g.text(font, t, tstart + 16, by + (bh - 8) / 2, 0xFFFFFFFF, true);
        hits.add(new Hit(bx, by, bw, bh, () -> minecraft.setScreen(new ModMenuScreen(parent, null))));

        int ty = by + bh + 6;
        String sn = "Snap " + (snap ? "ON" : "OFF"), gd = "Guides " + (guides ? "ON" : "OFF");
        boolean h1 = in(mx, my, cx - 72, ty, 68, 14), h2 = in(mx, my, cx + 4, ty, 68, 14);
        GlassUi.button(g, cx - 72, ty, 68, 14, h1, snap);
        GlassUi.button(g, cx + 4, ty, 68, 14, h2, guides);
        g.text(font, sn, cx - 72 + 34 - font.width(sn) / 2, ty + 3, 0xFFFFFFFF, false);
        g.text(font, gd, cx + 4 + 34 - font.width(gd) / 2, ty + 3, 0xFFFFFFFF, false);
        hits.add(new Hit(cx - 72, ty, 68, 14, () -> snap = !snap));
        hits.add(new Hit(cx + 4, ty, 68, 14, () -> guides = !guides));
        String keys = "S snap  |  A align";
        g.text(font, keys, cx - font.width(keys) / 2, ty + 18, GlassUi.DIM, false);

        String hint = "Drag modules to reposition  |  Right-click for options  |  Right Shift to close";
        g.text(font, hint, cx - font.width(hint) / 2, height - 22, 0xFFFFD9DE, true);
        String credit = "UI layout inspired by Fast Client - thanks NoduweyLo";
        g.text(font, credit, cx - font.width(credit) / 2, height - 32, GlassUi.DIM, false);

        super.extractRenderState(g, mouseX, mouseY, delta);
    }

    @Override
    public boolean mouseClicked(MouseButtonEvent e, boolean dbl) {
        if (super.mouseClicked(e, dbl)) return true;
        int x = (int) e.x(), y = (int) e.y();
        for (int i = hits.size() - 1; i >= 0; i--) {
            Hit h = hits.get(i);
            if (in(x, y, h.x(), h.y(), h.w(), h.h())) { h.run().run(); return true; }
        }
        List<HudModule> mods = HudManager.MODULES;
        for (int i = mods.size() - 1; i >= 0; i--) {
            HudModule m = mods.get(i);
            if (!m.s.enabled || !in(x, y, m.lastX, m.lastY, m.lastW, m.lastH)) continue;
            if (e.button() == 1) {
                minecraft.setScreen(new ModMenuScreen(parent, ModRegistry.forHud(m)));
            } else {
                dragging = m; grabX = x - m.lastX; grabY = y - m.lastY;
            }
            return true;
        }
        return false;
    }

    @Override
    public boolean mouseDragged(MouseButtonEvent e, double dx, double dy) {
        if (dragging != null) {
            int nx = (int) e.x() - grabX, ny = (int) e.y() - grabY;
            if (snap) { nx = Math.round(nx / 8f) * 8; ny = Math.round(ny / 8f) * 8; }
            dragging.moveTo(minecraft, nx, ny);
            return true;
        }
        return super.mouseDragged(e, dx, dy);
    }

    @Override
    public boolean mouseReleased(MouseButtonEvent e) {
        dragging = null;
        return super.mouseReleased(e);
    }

    @Override
    public boolean keyPressed(KeyEvent e) {
        int k = e.key();
        if (k == 344) { onClose(); return true; }   // Right Shift
        if (k == 83) { snap = !snap; return true; }  // S
        if (k == 65) { guides = !guides; return true; } // A
        return super.keyPressed(e);
    }

    @Override
    public void onClose() {
        EclipseConfig.save();
        minecraft.setScreen(parent);
    }
}
