package dev.eclipse.client.util;

import net.minecraft.client.gui.GuiGraphicsExtractor;

/**
 * Flat Eclipse UI primitives. Uses opaque charcoal panels and purple accents.
 * Everything is drawn with plain fills, row by row, so it needs no textures or shaders.
 */
public final class GlassUi {
    private GlassUi() {}

    public static final int PURPLE = 0xFF8B5CF6;
    public static final int PURPLE_LIGHT = 0xFFC4B5FD;
    public static final int PURPLE_DARK = 0xFF4C1D95;

    // Flat, high-contrast purple/black UI. No blur, glass, shine, gradients or rounded pills.
    public static int lerp(int a, int b, float t) {
        t = Math.max(0f, Math.min(1f, t));
        int aa = (int) (((a >>> 24) & 255) + (((b >>> 24) & 255) - ((a >>> 24) & 255)) * t);
        int ar = (int) (((a >> 16) & 255) + (((b >> 16) & 255) - ((a >> 16) & 255)) * t);
        int ag = (int) (((a >> 8) & 255) + (((b >> 8) & 255) - ((a >> 8) & 255)) * t);
        int ab = (int) ((a & 255) + ((b & 255) - (a & 255)) * t);
        return (aa << 24) | (ar << 16) | (ag << 8) | ab;
    }

    public static void round(GuiGraphicsExtractor g, int x, int y, int w, int h, int r, int top, int bottom) {
        g.fill(x, y, x + w, y + h, top);
    }
    public static void round(GuiGraphicsExtractor g, int x, int y, int w, int h, int r, int color) {
        g.fill(x, y, x + w, y + h, color);
    }
    public static void rim(GuiGraphicsExtractor g, int x, int y, int w, int h, int r, int top, int bottom) {
        g.fill(x, y, x + w, y + 1, top);
        g.fill(x, y + h - 1, x + w, y + h, bottom);
        g.fill(x, y, x + 1, y + h, top);
        g.fill(x + w - 1, y, x + w, y + h, bottom);
    }
    public static void panel(GuiGraphicsExtractor g, int x, int y, int w, int h) { panel(g, x, y, w, h, 0); }
    public static void panel(GuiGraphicsExtractor g, int x, int y, int w, int h, int r) {
        g.fill(x, y, x + w, y + h, 0xF20B0A12);
        g.fill(x, y, x + w, y + 2, PURPLE);
        rim(g, x, y, w, h, 0, 0xFF39245E, 0xFF211833);
    }
    public static void card(GuiGraphicsExtractor g, int x, int y, int w, int h, boolean hover, boolean selected) {
        int base = selected ? 0xFF38205D : hover ? 0xFF24202F : 0xFF17151E;
        g.fill(x, y, x + w, y + h, base);
        if (selected) g.fill(x, y, x + 2, y + h, PURPLE);
        else if (hover) g.fill(x, y, x + 1, y + h, 0xFF7651B8);
    }
    public static void pill(GuiGraphicsExtractor g, int x, int y, int w, int h, boolean hover, boolean accent) {
        g.fill(x, y, x + w, y + h, accent ? (hover ? 0xFF9A65F5 : PURPLE) : (hover ? 0xFF393344 : 0xFF24212D));
    }
    public static void toggle(GuiGraphicsExtractor g, int x, int y, boolean on) {
        g.fill(x, y, x + 20, y + 10, on ? PURPLE : 0xFF393541);
        int kx = on ? x + 11 : x + 1;
        g.fill(kx, y + 1, kx + 8, y + 9, 0xFFFFFFFF);
    }
    public static void segmentBar(GuiGraphicsExtractor g, int x, int y, int w, int h) {
        g.fill(x, y, x + w, y + h, 0xFF111018);
        g.fill(x, y + h - 1, x + w, y + h, 0xFF332447);
    }

    /** Backwards-compatible helper used by older screens. */
    public static void button(GuiGraphicsExtractor g, int x, int y, int w, int h, boolean hover, boolean on) {
        pill(g, x, y, w, h, hover, on);
    }
}
