package dev.eclipse.client;

import com.mojang.blaze3d.platform.InputConstants;
import dev.eclipse.client.config.EclipseConfig;
import dev.eclipse.client.fps.FpsGuard;
import dev.eclipse.client.hud.CpsHud;
import dev.eclipse.client.hud.SpeedHud;
import dev.eclipse.client.hud.HudManager;
import dev.eclipse.client.screen.HudEditorScreen;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keymapping.v1.KeyMappingHelper;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.fabricmc.fabric.api.client.screen.v1.Screens;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.gui.screens.PauseScreen;
import net.minecraft.client.gui.components.Button;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import org.lwjgl.glfw.GLFW;

public class EclipseClient implements ClientModInitializer {
    public static final String MOD_ID = "eclipse_client";
    private static KeyMapping openEditor;
    private static Boolean appliedToggle;
    private static boolean fullbrightApplied;
    private static String appliedParticles = "vanilla";
    private static net.minecraft.client.ParticleStatus particlesOriginal;
    private static Boolean bobOriginal;
    private static KeyMapping zoomKey;
    private static KeyMapping.Category CATEGORY;
    private static int savedFov = -1;

    @Override
    public void onInitializeClient() {
        EclipseConfig.load();
        HudManager.register();

        // register the key category ONCE (registering the same category twice throws)
        CATEGORY = KeyMapping.Category.register(Identifier.fromNamespaceAndPath(MOD_ID, "main"));

        openEditor = KeyMappingHelper.registerKeyMapping(new KeyMapping(
                "key.eclipse_client.editor", InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_RIGHT_SHIFT, CATEGORY));

        zoomKey = KeyMappingHelper.registerKeyMapping(new KeyMapping(
                "key.eclipse_client.zoom", InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_C, CATEGORY));

        ClientLifecycleEvents.CLIENT_STOPPING.register(mc -> {
            if (savedFov >= 0) mc.options.fov().set(savedFov); // don't save a half-zoomed FOV
            EclipseConfig.save();
        });

        ClientTickEvents.END_CLIENT_TICK.register(mc -> {
            // smooth hold-to-zoom by easing the FOV option
            var fov = mc.options.fov();
            boolean zooming = zoomKey.isDown() && mc.screen == null;
            if (zooming) {
                if (savedFov < 0) savedFov = fov.get();
                int target = EclipseConfig.get().zoomFov, cur = fov.get();
                if (cur != target) fov.set(cur + Math.max(-12, Math.min(12, target - cur)));
            } else if (savedFov >= 0) {
                int cur = fov.get();
                if (cur >= savedFov) { fov.set(savedFov); savedFov = -1; }
                else fov.set(Math.min(savedFov, cur + 12));
            }
            // drain every queued press so a stale click can't re-open the editor later
            boolean wantEditor = false;
            while (openEditor.consumeClick()) wantEditor = true;
            if (wantEditor && mc.screen == null) mc.setScreen(new HudEditorScreen(null));
            CpsHud.tick(mc);
            SpeedHud.tick(mc);
            FpsGuard.tick(mc);
            String bm = EclipseConfig.get().bobMode;
            if (!bm.equals("vanilla")) {
                if (bobOriginal == null) bobOriginal = mc.options.bobView().get();
                mc.options.bobView().set(bm.equals("on"));
            } else if (bobOriginal != null) {
                mc.options.bobView().set(bobOriginal); // back to the player's own setting
                bobOriginal = null;
            }
            // Fullbright: client-side night vision while enabled
            if (mc.player != null) {
                boolean has = mc.player.hasEffect(net.minecraft.world.effect.MobEffects.NIGHT_VISION);
                if (EclipseConfig.get().fullbright && !has) {
                    mc.player.addEffect(new net.minecraft.world.effect.MobEffectInstance(net.minecraft.world.effect.MobEffects.NIGHT_VISION, 1_000_000, 0, false, false));
                    fullbrightApplied = true;
                } else if (!EclipseConfig.get().fullbright && fullbrightApplied) {
                    mc.player.removeEffect(net.minecraft.world.effect.MobEffects.NIGHT_VISION);
                    fullbrightApplied = false;
                }
            }
            // Particles level
            String pm = EclipseConfig.get().particles;
            if (!pm.equals(appliedParticles)) {
                if (pm.equals("vanilla")) {
                    if (particlesOriginal != null) { mc.options.particles().set(particlesOriginal); particlesOriginal = null; }
                } else {
                    if (particlesOriginal == null) particlesOriginal = mc.options.particles().get();
                    mc.options.particles().set(switch (pm) {
                        case "minimal" -> net.minecraft.client.ParticleStatus.MINIMAL;
                        case "decreased" -> net.minecraft.client.ParticleStatus.DECREASED;
                        default -> net.minecraft.client.ParticleStatus.ALL;
                    });
                }
                appliedParticles = pm;
            }
            // sync Eclipse's Toggle Sprint switch with the game's own "Sprint: Toggle" option
            boolean wantToggle = EclipseConfig.get().toggleSprint;
            if (appliedToggle == null && !wantToggle) {
                appliedToggle = false; // first tick: leave the player's own game setting alone
            } else if (appliedToggle == null || appliedToggle != wantToggle) {
                mc.options.toggleSprint().set(wantToggle);
                appliedToggle = wantToggle;
            }
        });

        ScreenEvents.AFTER_INIT.register((mc, screen, w, h) -> {
            if (screen instanceof PauseScreen) {
                Screens.getWidgets(screen).add(Button.builder(Component.literal("Eclipse HUD"),
                        b -> mc.setScreen(new HudEditorScreen(screen))).bounds(6, 6, 80, 20).build());
            }
        });
    }
}
