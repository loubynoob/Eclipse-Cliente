package dev.eclipse.client.mod;

import dev.eclipse.client.config.EclipseConfig;
import dev.eclipse.client.hud.HudManager;
import dev.eclipse.client.hud.HudModule;
import dev.eclipse.client.screen.SkyScreen;
import dev.eclipse.client.sky.SkyPresets;
import net.minecraft.client.Minecraft;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.function.BooleanSupplier;
import java.util.function.Consumer;

/** Every module shown in the Mod Menu: all HUDs plus the render / movement / player / utility features. */
public final class ModRegistry {
    private ModRegistry() {}

    public static final String[] CATEGORIES = {"All", "HUD", "Render", "Movement", "Player", "Utility"};

    private static List<ModEntry> all;

    public static List<ModEntry> all() {
        if (all == null) build();
        return all;
    }

    public static ModEntry forHud(HudModule m) {
        for (ModEntry e : all()) if (e.hud() == m) return e;
        return null;
    }

    // ---------- HUD wrapper ----------
    private static final class HudEntry extends ModEntry {
        private final HudModule m;

        HudEntry(HudModule m, String category) {
            super(m.id, m.name, category, iconFor(m));
            this.m = m;
        }

        @Override public HudModule hud() { return m; }
        @Override public boolean enabled() { return m.s.enabled; }
        @Override public void setEnabled(boolean on) { m.s.enabled = on; }

        @Override
        public void reset() {
            m.s.scale = 1f;
            m.s.background = true;
            m.s.shadow = true;
            m.s.textColor = "#FFFFFF";
            m.s.bgColor = "#00000066";
            m.s.extra.clear();
        }

        @Override
        public void settings(SettingsUi ui) {
            ui.header("Display");
            ui.toggle("Background", m.s.background, () -> m.s.background = !m.s.background);
            ui.toggle("Shadow", m.s.shadow, () -> m.s.shadow = !m.s.shadow);
            ui.stepper("Scale", String.format(Locale.ROOT, "%.1f", m.s.scale),
                    () -> m.s.scale = Math.max(0.5f, m.s.scale - 0.1f),
                    () -> m.s.scale = Math.min(3f, m.s.scale + 0.1f));
            ui.stepper("Position X", Math.round(m.s.x * 100) + "%",
                    () -> m.s.x = Math.max(0f, m.s.x - 0.02f), () -> m.s.x = Math.min(1f, m.s.x + 0.02f));
            ui.stepper("Position Y", Math.round(m.s.y * 100) + "%",
                    () -> m.s.y = Math.max(0f, m.s.y - 0.02f), () -> m.s.y = Math.min(1f, m.s.y + 0.02f));
            ui.header("Colors");
            ui.hex("text", "Text", m.s.textColor, v -> m.s.textColor = v);
            ui.hex("bg", "Background", m.s.bgColor, v -> m.s.bgColor = v);
            if (m.id.equals("armor")) {
                ui.hex("num", "Numbers", m.opt("numColorHex", "#FFFFFF"), v -> m.s.extra.put("numColorHex", v));
            }
            List<HudModule.Option> opts = m.options();
            if (!opts.isEmpty()) ui.header("Options");
            for (HudModule.Option o : opts) {
                final HudModule.Option opt = o;
                ui.cycle(o.label(), m.opt(o.key(), o.choices()[0]), () -> {
                    String cc = m.opt(opt.key(), opt.choices()[0]);
                    int i = 0;
                    for (int k = 0; k < opt.choices().length; k++) if (opt.choices()[k].equals(cc)) i = k;
                    m.s.extra.put(opt.key(), opt.choices()[(i + 1) % opt.choices().length]);
                });
            }
        }
    }

    private static String iconFor(HudModule m) {
        return switch (m.id) {
            case "fps" -> "FPS";
            case "cps" -> "CPS";
            case "keystrokes" -> "WASD";
            case "armor" -> "ARM";
            case "coords" -> "XYZ";
            case "survival" -> "SRV";
            case "movement" -> "MOV";
            case "potions" -> "POT";
            case "ping" -> "MS";
            case "speed" -> "SPD";
            case "arrows" -> "ARW";
            case "memory" -> "RAM";
            case "realtime" -> "CLK";
            case "compass" -> "DIR";
            case "players" -> "PLR";
            case "crosshair" -> "+";
            case "helditem" -> "ITM";
            case "tnt" -> "TNT";
            case "serverip" -> "IP";
            case "biome" -> "BIO";
            case "saturation" -> "SAT";
            case "daycounter" -> "DAY";
            case "health" -> "HP";
            case "session" -> "TIME";
            case "chunk" -> "CHK";
            case "combo" -> "HIT";
            default -> m.name.substring(0, Math.min(3, m.name.length())).toUpperCase(Locale.ROOT);
        };
    }

    // ---------- non-HUD modules ----------
    private static final class Simple extends ModEntry {
        private final BooleanSupplier get;
        private final Consumer<Boolean> set;
        private final Consumer<SettingsUi> ui;

        Simple(String id, String name, String cat, String icon, BooleanSupplier get, Consumer<Boolean> set, Consumer<SettingsUi> ui) {
            super(id, name, cat, icon);
            this.get = get; this.set = set; this.ui = ui;
        }

        @Override public boolean enabled() { return get.getAsBoolean(); }
        @Override public void setEnabled(boolean on) { set.accept(on); }
        @Override public void settings(SettingsUi u) { ui.accept(u); }
    }

    private static String nextOf(String cur, String... opts) {
        for (int i = 0; i < opts.length; i++) if (opts[i].equals(cur)) return opts[(i + 1) % opts.length];
        return opts[0];
    }

    private static void build() {
        final EclipseConfig c = EclipseConfig.get();
        List<ModEntry> l = new ArrayList<>();

        for (HudModule m : HudManager.MODULES) {
            String cat = switch (m.id) {
                case "crosshair" -> "Render";
                case "movement" -> "Movement";
                default -> "HUD";
            };
            l.add(new HudEntry(m, cat));
        }

        // ---- Render ----
        l.add(new Simple("fullbright", "Fullbright", "Render", "SUN", () -> c.fullbright, v -> c.fullbright = v,
                ui -> ui.note("Client-side night vision. Sees in the dark.")));
        l.add(new Simple("fog", "Fog Overlay", "Render", "FOG", () -> c.fogEnabled, v -> c.fogEnabled = v, ui -> {
            ui.header("Style");
            ui.cycle("Mode", c.fogMode, () -> c.fogMode = nextOf(c.fogMode, "tint", "vignette", "both"));
            ui.stepper("Opacity", c.fogOpacity + "%",
                    () -> c.fogOpacity = Math.max(0, c.fogOpacity - 5), () -> c.fogOpacity = Math.min(100, c.fogOpacity + 5));
            ui.stepper("Edge size", c.fogEdge + "%",
                    () -> c.fogEdge = Math.max(10, c.fogEdge - 5), () -> c.fogEdge = Math.min(60, c.fogEdge + 5));
            ui.hex("fogColor", "Color", c.fogColor, v -> c.fogColor = v);
            ui.header("Animation");
            ui.toggle("Pulse", c.fogPulse, () -> c.fogPulse = !c.fogPulse);
            ui.stepper("Pulse speed", String.valueOf(c.fogPulseSpeed),
                    () -> c.fogPulseSpeed = Math.max(1, c.fogPulseSpeed - 1), () -> c.fogPulseSpeed = Math.min(10, c.fogPulseSpeed + 1));
            ui.note("Colored haze over your screen.");
        }));
        l.add(new Simple("sky", "Sky Presets", "Render", "SKY", () -> c.skyPreset != 0,
                v -> c.skyPreset = v ? (c.skyPreset == 0 ? 1 : c.skyPreset) : 0, ui -> {
            int n = SkyPresets.ALL.length;
            ui.cycle("Preset", SkyPresets.ALL[Math.max(0, Math.min(n - 1, c.skyPreset))].name(),
                    () -> c.skyPreset = (c.skyPreset + 1) % n);
            ui.cycle("Open list", ">", () -> Minecraft.getInstance().setScreen(new SkyScreen(Minecraft.getInstance().screen)));
        }));
        l.add(new Simple("brightinv", "Bright Inventory", "Render", "INV", () -> c.brightInventory, v -> c.brightInventory = v,
                ui -> ui.note("Lighter backdrop behind inventories.")));
        l.add(new Simple("particles", "Particles", "Render", "PRT", () -> !c.particles.equals("vanilla"),
                v -> c.particles = v ? (c.particles.equals("vanilla") ? "decreased" : c.particles) : "vanilla",
                ui -> ui.cycle("Level", c.particles, () -> c.particles = nextOf(c.particles, "all", "decreased", "minimal"))));
        l.add(new Simple("bobbing", "No View Bobbing", "Render", "BOB", () -> c.bobMode.equals("off"),
                v -> c.bobMode = v ? "off" : "vanilla",
                ui -> ui.cycle("Mode", c.bobMode, () -> c.bobMode = nextOf(c.bobMode, "vanilla", "on", "off"))));
        l.add(new Simple("extradist", "Extra Distance", "Render", "+1", () -> c.extraDist, v -> c.extraDist = v, ui -> {
            ui.stepper("Render +", String.valueOf(c.extraRender),
                    () -> c.extraRender = Math.max(0, c.extraRender - 1), () -> c.extraRender = Math.min(4, c.extraRender + 1));
            ui.stepper("Simulation +", String.valueOf(c.extraSim),
                    () -> c.extraSim = Math.max(0, c.extraSim - 1), () -> c.extraSim = Math.min(4, c.extraSim + 1));
            ui.note("Added on top of YOUR settings.");
            ui.note("FPS Guard pauses while this is ON.");
        }));

        // ---- Movement ----
        l.add(new Simple("togglesprint", "Toggle Sprint", "Movement", "SPR", () -> c.toggleSprint, v -> c.toggleSprint = v,
                ui -> ui.note("Tap sprint once to keep sprinting.")));
        l.add(new Simple("togglesneak", "Toggle Sneak", "Movement", "SNK", () -> c.toggleSneak, v -> c.toggleSneak = v,
                ui -> ui.note("Tap sneak once to keep sneaking.")));

        // ---- Player ----
        l.add(new Simple("selflogo", "Name Logo", "Player", "LOGO", () -> c.selfLogo, v -> c.selfLogo = v,
                ui -> ui.note("Eclipse logo next to your own name.")));

        // ---- Utility ----
        l.add(new Simple("zoom", "Zoom", "Utility", "ZM", () -> c.zoomEnabled, v -> c.zoomEnabled = v, ui ->
                ui.stepper("Zoom FOV", String.valueOf(c.zoomFov),
                        () -> c.zoomFov = Math.max(30, c.zoomFov - 5), () -> c.zoomFov = Math.min(70, c.zoomFov + 5))));
        l.add(new Simple("fpsguard", "FPS Guard", "Utility", "GRD", () -> c.fpsGuard, v -> c.fpsGuard = v, ui -> {
            ui.stepper("Target FPS", String.valueOf(c.fpsTarget),
                    () -> c.fpsTarget = Math.max(20, c.fpsTarget - 10), () -> c.fpsTarget = Math.min(240, c.fpsTarget + 10));
            ui.note("Lowers render distance when FPS drops.");
        }));
        l.add(new Simple("ecltitle", "Eclipse Title Screen", "Utility", "TTL", () -> c.eclipseTitle, v -> c.eclipseTitle = v,
                ui -> ui.note("Takes effect next time you open the title screen.")));
        l.add(new Simple("eclload", "Eclipse Loading Screen", "Utility", "LOD", () -> c.eclipseLoading, v -> c.eclipseLoading = v,
                ui -> ui.note("Takes effect next launch.")));

        all = l;
    }
}
