package dev.eclipse.client.mixin;

import dev.eclipse.client.util.GlassUi;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.AbstractWidget;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Adds the neutral translucent-white glass treatment to vanilla buttons on world/server screens. */
@Mixin(AbstractWidget.class)
public abstract class VanillaWidgetMixin {
    @Inject(method = "extractRenderState", at = @At("TAIL"), require = 0)
    private void eclipse$glassWidget(GuiGraphicsExtractor g, int mouseX, int mouseY, float delta, CallbackInfo ci) {
        AbstractWidget self = (AbstractWidget) (Object) this;
        if (!self.visible) return;
        int x = self.getX(), y = self.getY(), w = self.getWidth(), h = self.getHeight();
        boolean hover = mouseX >= x && mouseX < x + w && mouseY >= y && mouseY < y + h;
        GlassUi.vanillaWidget(g, x, y, w, h, hover);
    }
}
