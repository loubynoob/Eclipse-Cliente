package dev.eclipse.client.util;

import com.google.gson.JsonParser;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.serialization.JsonOps;
import dev.eclipse.client.EclipseClient;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.ComponentSerialization;
import net.minecraft.resources.Identifier;

public final class Branding {
    private Branding() {}

    public static final Identifier LOGO16 = Identifier.fromNamespaceAndPath(EclipseClient.MOD_ID, "textures/gui/logo16.png");
    public static final Identifier LOGO64 = Identifier.fromNamespaceAndPath(EclipseClient.MOD_ID, "textures/gui/logo64.png");

    private static String versionLine;
    private static Component logoInline;

    /** Bottom-right "[logo] ECLIPSE CLIENT", bottom-left "Version x (vY)". */
    public static void draw(GuiGraphicsExtractor g, int w, int h) {
        Minecraft mc = Minecraft.getInstance();
        Component t = Component.literal("ECLIPSE CLIENT").withStyle(net.minecraft.ChatFormatting.BOLD);
        int tw = mc.font.width(t);
        int x = w - tw - 6, y = h - 12;
        g.text(mc.font, t, x, y, 0xFFFF6578, true);
        g.blit(RenderPipelines.GUI_TEXTURED, LOGO16, x - 18, y - 4, 0f, 0f, 16, 16, 16, 16);
        g.text(mc.font, versionLine(), 2, h - 10, 0xFFFFFFFF, true);
    }

    /** Only the bottom-left "Version x (vY)" line (used by screens that draw their own name). */
    public static void drawVersion(GuiGraphicsExtractor g, int h) {
        Minecraft mc = Minecraft.getInstance();
        g.text(mc.font, versionLine(), 2, h - 10, 0xFFFFFFFF, true);
    }

    /** Eclipse build shown after the Minecraft version, e.g. "Version 26.1.2 (v1.0.2-1)". */
    public static final String ECLIPSE_BUILD = "v1.0.4-1";

    private static String versionLine() {
        if (versionLine == null) {
            String mcv = FabricLoader.getInstance().getModContainer("minecraft")
                    .map(c -> c.getMetadata().getVersion().getFriendlyString()).orElse("?");
            versionLine = "Version " + mcv + " (" + ECLIPSE_BUILD + ")";
        }
        return versionLine;
    }

    /** Inline logo glyph (custom font) built from JSON so we avoid Style/font API changes. */
    public static Component logo() {
        if (logoInline == null) {
            try {
                var json = JsonParser.parseString("{\"text\":\"\\ue000\",\"font\":\"eclipse_client:logo\"}");
                logoInline = ComponentSerialization.CODEC.parse(JsonOps.INSTANCE, json).result().orElse(Component.empty());
            } catch (Throwable t) {
                logoInline = Component.empty();
            }
        }
        return logoInline;
    }

    public static Component withLogo(Component original) {
        return Component.empty().append(logo()).append(Component.literal(" ")).append(original);
    }
}
