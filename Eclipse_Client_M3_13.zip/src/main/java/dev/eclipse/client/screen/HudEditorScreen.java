package dev.eclipse.client.screen;

import dev.eclipse.client.config.EclipseConfig;
import dev.eclipse.client.hud.HudManager;
import dev.eclipse.client.hud.HudModule;
import dev.eclipse.client.util.ColorUtil;
import dev.eclipse.client.util.GlassUi;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Eclipse menu in liquid-glass style, three tabs:  PvP | Survival | Visuals.
 * Left: module list with switches (and a Preferences page).  Right: settings of the selected module.
 * The middle stays free so HUDs can be dragged around.  Works from the title screen too (preview mode).
 * Layout idea (tabs + module cards + per-module settings) is inspired by Fast Client - thanks NoduweyLo.
 */
public class HudEditorScreen extends Screen {
    private static final String[] TABS = {"PvP", "Survival", "Visuals"};
    private static final int RH = 14;                 // row height
    private static final int TXT = 0xFFF3EEFF;
    private static final int DIM = 0xFFB9A8E8;

    private record Hit(int x, int y, int w, int h, Runnable run) {}

    private final Screen parent;
    private int tab;
    private HudModule selected, dragging;
    private boolean general;                          // showing the Preferences page
    private int grabX, grabY;
    private EditBox textColor, bgColor, numColor;

    private final List<Hit> hits = new ArrayList<>();
    private int mx, my;
    private int scrollL, scrollR, maxL, maxR;

    // row layout state (one scrolling region at a time)
    private int rowX, rowW, viewTop, viewBottom, cy;

    public HudEditorScreen(Screen parent) {
        super(Component.literal("Eclipse"));
        this.parent = parent;
        tab = Math.max(0, Math.min(2, EclipseConfig.get().editorTab));
        selected = firstOfTab();
    }

    private static int tabOf(HudModule m) {
        return m.group.equals("Survival") ? 1 : 0;
    }

    private List<HudModule> modulesOfTab() {
        List<HudModule> out = new ArrayList<>();
        for (HudModule m : HudManager.MODULES) if (tab != 2 && tabOf(m) == tab) out.add(m);
        return out;
    }

    private HudModule firstOfTab() {
        List<HudModule> l = modulesOfTab();
        return l.isEmpty() ? null : l.get(0);
    }

    private static String onOff(boolean b) { return b ? "ON" : "OFF"; }

    private static boolean in(int px, int py, int x, int y, int w, int h) {
        return px >= x && px < x + w && py >= y && py < y + h;
    }

    // ---------- panel geometry ----------
    private int panelTop() { return 26; }
    private int panelH() { return Math.max(40, height - 46 - 26); }
    private int leftX() { return 6; }
    private int leftW() { return 142; }
    private int rightW() { return 170; }
    private int rightX() { return width - rightW() - 6; }

    private boolean overPanel(double x, double y) {
        int py = panelTop(), ph = panelH();
        if (tab == 2) return in((int) x, (int) y, width / 2 - 100, py, 200, ph);
        return in((int) x, (int) y, leftX(), py, leftW(), ph) || in((int) x, (int) y, rightX(), py, rightW(), ph);
    }

    private void switchTab(int idx) {
        tab = idx;
        EclipseConfig.get().editorTab = idx;
        selected = firstOfTab();
        general = false;
        scrollL = 0; scrollR = 0;
        init();
    }

    private void select(HudModule m) {
        selected = m; general = false; scrollR = 0;
        init();
    }

    // ---------- widgets (only the hex boxes are real widgets) ----------
    @Override
    protected void init() {
        clearWidgets();
        textColor = null; bgColor = null; numColor = null;
        if (tab == 2 || general || selected == null) return;
        final HudModule m = selected;
        textColor = new EditBox(font, -200, -200, 54, 12, Component.literal("Text #hex"));
        textColor.setMaxLength(9); textColor.setValue(m.s.textColor);
        textColor.setResponder(v -> { if (ColorUtil.isValid(v)) m.s.textColor = v; });
        addRenderableWidget(textColor);
        bgColor = new EditBox(font, -200, -200, 54, 12, Component.literal("Background #hex"));
        bgColor.setMaxLength(9); bgColor.setValue(m.s.bgColor);
        bgColor.setResponder(v -> { if (ColorUtil.isValid(v)) m.s.bgColor = v; });
        addRenderableWidget(bgColor);
        if (m.id.equals("armor")) {
            numColor = new EditBox(font, -200, -200, 54, 12, Component.literal("Number #hex"));
            numColor.setMaxLength(9); numColor.setValue(m.opt("numColorHex", "#FFFFFF"));
            numColor.setResponder(v -> { if (ColorUtil.isValid(v)) m.s.extra.put("numColorHex", v); });
            addRenderableWidget(numColor);
        }
    }

    private static void park(EditBox b) {
        if (b != null) { b.setX(-200); b.setY(-200); }
    }

    // ---------- row helpers ----------
    private void begin(int x, int w, int top, int bottom, int scroll) {
        rowX = x; rowW = w; viewTop = top; viewBottom = bottom;
        cy = top - scroll;
    }

    /** Returns the maximum scroll for the region just drawn. */
    private int end(int scroll) {
        int content = cy + scroll - viewTop;
        return Math.max(0, content - (viewBottom - viewTop));
    }

    private boolean vis() { return cy >= viewTop && cy + RH <= viewBottom; }

    private void rowHeader(GuiGraphicsExtractor g, String t) {
        if (vis()) g.text(font, t, rowX + 2, cy + 3, GlassUi.PURPLE_LIGHT, false);
        cy += RH;
    }

    private void rowToggle(GuiGraphicsExtractor g, String label, boolean on, Runnable a) {
        if (vis()) {
            boolean hov = in(mx, my, rowX, cy, rowW, RH - 1);
            GlassUi.card(g, rowX, cy, rowW, RH - 1, hov, false);
            g.text(font, label, rowX + 5, cy + 3, TXT, false);
            GlassUi.toggle(g, rowX + rowW - 24, cy + 2, on);
            hits.add(new Hit(rowX, cy, rowW, RH - 1, a));
        }
        cy += RH;
    }

    private void rowCycle(GuiGraphicsExtractor g, String label, String value, Runnable a) {
        if (vis()) {
            boolean hov = in(mx, my, rowX, cy, rowW, RH - 1);
            GlassUi.card(g, rowX, cy, rowW, RH - 1, hov, false);
            g.text(font, label, rowX + 5, cy + 3, TXT, false);
            g.text(font, value, rowX + rowW - 5 - font.width(value), cy + 3, GlassUi.PURPLE_LIGHT, false);
            hits.add(new Hit(rowX, cy, rowW, RH - 1, a));
        }
        cy += RH;
    }

    private void rowStepper(GuiGraphicsExtractor g, String label, String value, Runnable minus, Runnable plus) {
        if (vis()) {
            GlassUi.card(g, rowX, cy, rowW, RH - 1, false, false);
            g.text(font, label, rowX + 5, cy + 3, TXT, false);
            int bx = rowX + rowW - 52, px = rowX + rowW - 16;
            boolean h1 = in(mx, my, bx, cy + 1, 12, 11), h2 = in(mx, my, px, cy + 1, 12, 11);
            GlassUi.pill(g, bx, cy + 1, 12, 11, h1, false);
            GlassUi.pill(g, px, cy + 1, 12, 11, h2, false);
            g.text(font, "-", bx + 4, cy + 3, 0xFFFFFFFF, false);
            g.text(font, "+", px + 4, cy + 3, 0xFFFFFFFF, false);
            g.text(font, value, bx + 12 + (px - bx - 12 - font.width(value)) / 2, cy + 3, GlassUi.PURPLE_LIGHT, false);
            hits.add(new Hit(bx, cy + 1, 12, 11, minus));
            hits.add(new Hit(px, cy + 1, 12, 11, plus));
        }
        cy += RH;
    }

    private void rowHex(GuiGraphicsExtractor g, String label, EditBox box) {
        if (box == null) { return; }
        if (vis()) {
            GlassUi.card(g, rowX, cy, rowW, RH - 1, false, false);
            g.text(font, label, rowX + 5, cy + 3, TXT, false);
            box.setX(rowX + rowW - 58);
            box.setY(cy);
        }
        cy += RH;
    }

    // ---------- drawing ----------
    @Override
    public void extractRenderState(GuiGraphicsExtractor g, int mouseX, int mouseY, float delta) {
        hits.clear();
        mx = mouseX; my = mouseY;
        g.fillGradient(0, 0, width, height, 0xA01E0F3C, 0xB00B0618);
        park(textColor); park(bgColor); park(numColor);

        if (tab != 2) {
            for (HudModule m : modulesOfTab()) {
                m.render(g, minecraft, true);
                if (m == selected && !general) {
                    g.outline(m.lastX - 1, m.lastY - 1, m.lastW + 2, m.lastH + 2, GlassUi.PURPLE_LIGHT);
                }
            }
        }

        drawTabs(g);
        if (tab == 2) drawVisuals(g);
        else { drawList(g); drawSettings(g); }

        String hint = tab == 0 ? "PvP - drag HUDs to move them" : tab == 1 ? "Survival - make it yours" : "Visuals - how it looks";
        g.text(font, hint, width / 2 - font.width(hint) / 2, height - 43, 0xFFE9D5FF, true);
        String credit = "UI layout inspired by Fast Client - thanks NoduweyLo";
        g.text(font, credit, width / 2 - font.width(credit) / 2, height - 33, DIM, false);

        int dx = width / 2 - 40, dy = height - 22;
        boolean hov = in(mx, my, dx, dy, 80, 16);
        GlassUi.pill(g, dx, dy, 80, 16, hov, true);
        g.text(font, "Done", dx + 40 - font.width("Done") / 2, dy + 4, 0xFFFFFFFF, true);
        hits.add(new Hit(dx, dy, 80, 16, this::onClose));

        super.extractRenderState(g, mouseX, mouseY, delta);
    }

    private void drawTabs(GuiGraphicsExtractor g) {
        int tw = 62, th = 14, total = TABS.length * tw + 4;
        int x0 = width / 2 - total / 2, y0 = 4;
        GlassUi.segmentBar(g, x0, y0, total, th + 4);
        for (int i = 0; i < TABS.length; i++) {
            final int idx = i;
            int x = x0 + 2 + i * tw, y = y0 + 2;
            boolean sel = tab == i, hov = in(mx, my, x, y, tw, th);
            if (sel) GlassUi.pill(g, x, y, tw, th, false, true);
            else if (hov) GlassUi.round(g, x, y, tw, th, th / 2, 0x30FFFFFF);
            g.text(font, TABS[i], x + (tw - font.width(TABS[i])) / 2, y + 3, sel ? 0xFFFFFFFF : DIM, sel);
            hits.add(new Hit(x, y, tw, th, () -> switchTab(idx)));
        }
    }

    private void drawList(GuiGraphicsExtractor g) {
        int px = leftX(), py = panelTop(), pw = leftW(), ph = panelH();
        GlassUi.panel(g, px, py, pw, ph);
        begin(px + 6, pw - 12, py + 6, py + ph - 6, scrollL);

        if (vis()) {
            boolean hov = in(mx, my, rowX, cy, rowW, RH - 1);
            GlassUi.card(g, rowX, cy, rowW, RH - 1, hov, general);
            g.text(font, "Preferences", rowX + 5, cy + 3, TXT, general);
            hits.add(new Hit(rowX, cy, rowW, RH - 1, () -> { general = true; selected = null; scrollR = 0; init(); }));
        }
        cy += RH;

        for (HudModule m : modulesOfTab()) {
            if (vis()) {
                boolean sel = (m == selected && !general);
                boolean hov = in(mx, my, rowX, cy, rowW, RH - 1);
                GlassUi.card(g, rowX, cy, rowW, RH - 1, hov, sel);
                g.text(font, m.name, rowX + 5, cy + 3, TXT, sel);
                GlassUi.toggle(g, rowX + rowW - 24, cy + 2, m.s.enabled);
                hits.add(new Hit(rowX, cy, rowW, RH - 1, () -> select(m)));
                hits.add(new Hit(rowX + rowW - 25, cy + 1, 22, RH - 3, () -> m.s.enabled = !m.s.enabled));
            }
            cy += RH;
        }
        maxL = end(scrollL);
        scrollL = Math.max(0, Math.min(maxL, scrollL));
    }

    private void drawSettings(GuiGraphicsExtractor g) {
        int px = rightX(), py = panelTop(), pw = rightW(), ph = panelH();
        GlassUi.panel(g, px, py, pw, ph);
        String title = general ? "Preferences" : selected != null ? selected.name : "";
        g.text(font, title, px + 8, py + 6, 0xFFFFFFFF, true);
        begin(px + 6, pw - 12, py + 20, py + ph - 6, scrollR);

        if (general) {
            prefRows(g);
        } else if (selected != null) {
            final HudModule m = selected;
            rowHeader(g, "Display");
            rowToggle(g, "HUD", m.s.enabled, () -> m.s.enabled = !m.s.enabled);
            rowToggle(g, "Background", m.s.background, () -> m.s.background = !m.s.background);
            rowToggle(g, "Shadow", m.s.shadow, () -> m.s.shadow = !m.s.shadow);
            rowStepper(g, "Scale", String.format(Locale.ROOT, "%.1f", m.s.scale),
                    () -> m.s.scale = Math.max(0.5f, m.s.scale - 0.1f),
                    () -> m.s.scale = Math.min(3f, m.s.scale + 0.1f));
            rowHeader(g, "Colors");
            rowHex(g, "Text", textColor);
            rowHex(g, "Background", bgColor);
            if (numColor != null) rowHex(g, "Numbers", numColor);
            List<HudModule.Option> opts = m.options();
            if (!opts.isEmpty()) rowHeader(g, "Options");
            for (HudModule.Option o : opts) {
                final HudModule.Option opt = o;
                rowCycle(g, o.label(), m.opt(o.key(), o.choices()[0]), () -> {
                    String cc = m.opt(opt.key(), opt.choices()[0]);
                    int i = 0;
                    for (int k = 0; k < opt.choices().length; k++) if (opt.choices()[k].equals(cc)) i = k;
                    m.s.extra.put(opt.key(), opt.choices()[(i + 1) % opt.choices().length]);
                });
            }
        }
        maxR = end(scrollR);
        scrollR = Math.max(0, Math.min(maxR, scrollR));
    }

    private void prefRows(GuiGraphicsExtractor g) {
        final EclipseConfig c = EclipseConfig.get();
        rowToggle(g, "Toggle Sprint", c.toggleSprint, () -> c.toggleSprint = !c.toggleSprint);
        if (tab == 1) {
            rowToggle(g, "FPS Guard", c.fpsGuard, () -> c.fpsGuard = !c.fpsGuard);
            rowCycle(g, "View bobbing", c.bobMode, () ->
                    c.bobMode = c.bobMode.equals("vanilla") ? "on" : c.bobMode.equals("on") ? "off" : "vanilla");
            rowCycle(g, "Zoom FOV", String.valueOf(c.zoomFov), () -> c.zoomFov = c.zoomFov >= 60 ? 30 : c.zoomFov + 10);
            rowToggle(g, "Fullbright", c.fullbright, () -> c.fullbright = !c.fullbright);
            rowCycle(g, "Particles", c.particles, () ->
                    c.particles = switch (c.particles) { case "vanilla" -> "all"; case "all" -> "decreased"; case "decreased" -> "minimal"; default -> "vanilla"; });
        }
    }

    private void drawVisuals(GuiGraphicsExtractor g) {
        int pw = 200, px = width / 2 - pw / 2, py = panelTop(), ph = panelH();
        GlassUi.panel(g, px, py, pw, ph);
        g.text(font, "How your Minecraft looks", px + 8, py + 6, 0xFFFFFFFF, true);
        begin(px + 6, pw - 12, py + 20, py + ph - 6, scrollR);
        final EclipseConfig c = EclipseConfig.get();
        rowCycle(g, "Sky presets", "Open >", () -> minecraft.setScreen(new SkyScreen(this)));
        rowToggle(g, "Bright inventory", c.brightInventory, () -> c.brightInventory = !c.brightInventory);
        rowToggle(g, "Logo next to name", c.selfLogo, () -> c.selfLogo = !c.selfLogo);
        rowToggle(g, "Eclipse title screen", c.eclipseTitle, () -> c.eclipseTitle = !c.eclipseTitle);
        rowToggle(g, "Eclipse loading screen", c.eclipseLoading, () -> c.eclipseLoading = !c.eclipseLoading);
        rowCycle(g, "View bobbing", c.bobMode, () ->
                c.bobMode = c.bobMode.equals("vanilla") ? "on" : c.bobMode.equals("on") ? "off" : "vanilla");
        maxR = end(scrollR);
        scrollR = Math.max(0, Math.min(maxR, scrollR));
    }

    // ---------- input ----------
    @Override
    public boolean mouseClicked(MouseButtonEvent e, boolean dbl) {
        if (super.mouseClicked(e, dbl)) return true;
        int x = (int) e.x(), y = (int) e.y();
        for (int i = hits.size() - 1; i >= 0; i--) {
            Hit h = hits.get(i);
            if (in(x, y, h.x(), h.y(), h.w(), h.h())) { h.run().run(); return true; }
        }
        if (overPanel(e.x(), e.y())) return true;
        for (HudModule m : modulesOfTab()) {
            if (x >= m.lastX && x <= m.lastX + m.lastW && y >= m.lastY && y <= m.lastY + m.lastH) {
                dragging = m; grabX = x - m.lastX; grabY = y - m.lastY;
                if (selected != m || general) select(m);
                return true;
            }
        }
        return false;
    }

    @Override
    public boolean mouseDragged(MouseButtonEvent e, double dx, double dy) {
        if (dragging != null) {
            dragging.moveTo(minecraft, (int) e.x() - grabX, (int) e.y() - grabY);
            return true;
        }
        return super.mouseDragged(e, dx, dy);
    }

    @Override
    public boolean mouseReleased(MouseButtonEvent e) {
        dragging = null;
        return super.mouseReleased(e);
    }

    @Override
    public boolean mouseScrolled(double x, double y, double sx, double sy) {
        int step = (int) Math.round(-sy * RH);
        if (tab == 2) {
            scrollR = Math.max(0, Math.min(maxR, scrollR + step));
            return true;
        }
        if (in((int) x, (int) y, leftX(), panelTop(), leftW(), panelH())) {
            scrollL = Math.max(0, Math.min(maxL, scrollL + step));
            return true;
        }
        if (in((int) x, (int) y, rightX(), panelTop(), rightW(), panelH())) {
            scrollR = Math.max(0, Math.min(maxR, scrollR + step));
            return true;
        }
        return super.mouseScrolled(x, y, sx, sy);
    }

    @Override
    public void onClose() {
        EclipseConfig.save();
        minecraft.setScreen(parent);
    }
}
