package dev.eclipse.client.util;

import net.minecraft.client.gui.GuiGraphicsExtractor;

/**
 * Original "liquid glass" look (frosted, translucent, bright specular rim, soft shadow, rounded corners).
 * Everything is drawn with plain fills, row by row, so it needs no textures or shaders.
 */
public final class GlassUi {
    private GlassUi() {}

    public static final int PURPLE = 0xFF8B5CF6;
    public static final int PURPLE_LIGHT = 0xFFC4B5FD;
    public static final int PURPLE_DARK = 0xFF4C1D95;

    // ---------- colour helpers ----------
    public static int lerp(int a, int b, float t) {
        t = Math.max(0f, Math.min(1f, t));
        int aa = (int) (((a >>> 24) & 255) + (((b >>> 24) & 255) - ((a >>> 24) & 255)) * t);
        int ar = (int) (((a >> 16) & 255) + (((b >> 16) & 255) - ((a >> 16) & 255)) * t);
        int ag = (int) (((a >> 8) & 255) + (((b >> 8) & 255) - ((a >> 8) & 255)) * t);
        int ab = (int) ((a & 255) + ((b & 255) - (a & 255)) * t);
        return (aa << 24) | (ar << 16) | (ag << 8) | ab;
    }

    /** Pixels cut off the left/right edge on row {@code i} (0 = top row) of a corner with radius r. */
    private static int inset(int i, int r) {
        double dy = r - i - 0.5;
        double dx = Math.sqrt(Math.max(0, (double) r * r - dy * dy));
        return (int) Math.ceil(r - dx);
    }

    /** Rounded rectangle with a vertical colour gradient. */
    public static void round(GuiGraphicsExtractor g, int x, int y, int w, int h, int r, int top, int bottom) {
        if (w <= 0 || h <= 0) return;
        r = Math.max(0, Math.min(r, Math.min(w, h) / 2));
        for (int i = 0; i < h; i++) {
            int ins = 0;
            if (i < r) ins = inset(i, r);
            else if (i >= h - r) ins = inset(h - 1 - i, r);
            int c = lerp(top, bottom, h <= 1 ? 0f : i / (float) (h - 1));
            g.fill(x + ins, y + i, x + w - ins, y + i + 1, c);
        }
    }

    public static void round(GuiGraphicsExtractor g, int x, int y, int w, int h, int r, int color) {
        round(g, x, y, w, h, r, color, color);
    }

    /** One-pixel rounded outline with a vertical colour gradient. */
    public static void rim(GuiGraphicsExtractor g, int x, int y, int w, int h, int r, int top, int bottom) {
        if (w <= 1 || h <= 1) return;
        r = Math.max(0, Math.min(r, Math.min(w, h) / 2));
        for (int i = 0; i < h; i++) {
            int ins = 0;
            if (i < r) ins = inset(i, r);
            else if (i >= h - r) ins = inset(h - 1 - i, r);
            int c = lerp(top, bottom, i / (float) (h - 1));
            if (i == 0 || i == h - 1) {
                g.fill(x + ins, y + i, x + w - ins, y + i + 1, c);
            } else {
                // widen to the previous/next row's inset so the corner arc stays connected
                int next = (i + 1 < r) ? inset(i + 1, r) : (i + 1 >= h - r && i + 1 < h ? inset(h - 2 - i, r) : 0);
                int span = Math.max(1, Math.abs(ins - next));
                g.fill(x + ins, y + i, x + ins + span, y + i + 1, c);
                g.fill(x + w - ins - span, y + i, x + w - ins, y + i + 1, c);
            }
        }
    }

    // ---------- glass pieces ----------

    /** Big frosted glass sheet. */
    public static void panel(GuiGraphicsExtractor g, int x, int y, int w, int h) {
        panel(g, x, y, w, h, 6);
    }

    public static void panel(GuiGraphicsExtractor g, int x, int y, int w, int h, int r) {
        round(g, x + 1, y + 3, w, h, r, 0x30000000);                       // soft drop shadow
        round(g, x, y, w, h, r, 0xC0231045, 0xC0150A2E);                    // deep violet base so text stays readable
        round(g, x, y, w, h, r, 0x48FFFFFF, 0x14C4B5FD);                    // milky glass, brighter at the top
        round(g, x + 2, y + 1, w - 4, Math.max(2, h / 5), Math.max(1, r - 2), 0x26FFFFFF, 0x00FFFFFF); // specular sheen
        rim(g, x, y, w, h, r, 0xC8FFFFFF, 0x50C4B5FD);                      // bright edge, fading toward the bottom
    }

    /** Smaller glass card (list entries, settings rows). */
    public static void card(GuiGraphicsExtractor g, int x, int y, int w, int h, boolean hover, boolean selected) {
        int r = Math.min(4, h / 2);
        if (selected) {
            round(g, x, y, w, h, r, 0xA0A78BFA, 0x808B5CF6);
            round(g, x + 1, y + 1, w - 2, Math.max(1, h / 2), Math.max(1, r - 1), 0x40FFFFFF, 0x00FFFFFF);
            rim(g, x, y, w, h, r, 0xE0FFFFFF, 0x90C4B5FD);
        } else {
            round(g, x, y, w, h, r, hover ? 0x40FFFFFF : 0x24FFFFFF, hover ? 0x22C4B5FD : 0x10C4B5FD);
            rim(g, x, y, w, h, r, hover ? 0x90FFFFFF : 0x50FFFFFF, 0x28C4B5FD);
        }
    }

    /** Pill-shaped button. */
    public static void pill(GuiGraphicsExtractor g, int x, int y, int w, int h, boolean hover, boolean accent) {
        int r = h / 2;
        if (accent) {
            round(g, x, y, w, h, r, hover ? 0xE0B79DFF : 0xC0A78BFA, hover ? 0xE08B5CF6 : 0xC07C4DE8);
        } else {
            round(g, x, y, w, h, r, hover ? 0x58FFFFFF : 0x38FFFFFF, hover ? 0x30C4B5FD : 0x18C4B5FD);
        }
        round(g, x + 2, y + 1, Math.max(1, w - 4), Math.max(1, h / 2 - 1), Math.max(1, r - 2), 0x30FFFFFF, 0x00FFFFFF);
        rim(g, x, y, w, h, r, 0xB0FFFFFF, 0x50C4B5FD);
    }

    /** iOS-style switch, 20 x 10 pixels. */
    public static void toggle(GuiGraphicsExtractor g, int x, int y, boolean on) {
        if (on) round(g, x, y, 20, 10, 5, 0xFFB79DFF, 0xFF7C4DE8);
        else round(g, x, y, 20, 10, 5, 0x60FFFFFF, 0x40C4B5FD);
        rim(g, x, y, 20, 10, 5, 0x90FFFFFF, 0x40FFFFFF);
        int kx = on ? x + 11 : x + 1;
        round(g, kx, y + 1, 8, 8, 4, 0xFFFFFFFF, 0xFFE4DBFF);
    }

    /** Segmented control background (the tab bar). */
    public static void segmentBar(GuiGraphicsExtractor g, int x, int y, int w, int h) {
        round(g, x, y, w, h, h / 2, 0x50000000, 0x30000000);
        rim(g, x, y, w, h, h / 2, 0x40FFFFFF, 0x20FFFFFF);
    }

    /** Backwards-compatible helper used by older screens. */
    public static void button(GuiGraphicsExtractor g, int x, int y, int w, int h, boolean hover, boolean on) {
        pill(g, x, y, w, h, hover, on);
    }
}
