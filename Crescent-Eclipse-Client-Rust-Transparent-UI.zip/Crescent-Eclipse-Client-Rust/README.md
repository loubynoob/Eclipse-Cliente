# Crescent Eclipse-Client — Rust + Fabric (Android ARM64 integration)

This source project keeps the Fabric/Java client entrypoint and adds an optional Rust JNI library. The Gradle build is configured to compile Rust for Android ARM64 and embed the resulting shared library in the mod JAR.

## What is configured

- Gradle task `installRustAndroidTarget` installs Rust's `aarch64-linux-android` target.
- Gradle task `buildRustAndroidArm64` invokes Cargo with the Android NDK Clang linker (Android API 26 minimum).
- Gradle task `packageRustAndroidArm64` stages `libcrescent_native.so` under `META-INF/native/android-arm64-v8a/`.
- `processResources` and `build` depend on the native build/package task.
- `NativeBridge` extracts the bundled `.so` on ARM64 Android and loads it with `System.load`. If the native library is missing or cannot load, it falls back to Java so the mod can still start.

## Build environment required

Use a computer or build environment with:

1. JDK 25 (required by this project's Minecraft/Fabric metadata).
2. Gradle compatible with the configured Fabric Loom release.
3. Rust toolchain installed through rustup, including `cargo` and `rustup` on PATH.
4. Android NDK installed, with `ANDROID_NDK_HOME` (or `ANDROID_NDK_ROOT`) pointing to its root directory.
5. Android NDK LLVM toolchain for the host operating system.

Then run from the project root:

```sh
gradle build
```

The output Fabric mod JAR will be in `build/libs/`. The native library is compiled for Android `arm64-v8a` only, with Android API 26 as the minimum target.

## Version configuration still required

`gradle.properties` intentionally leaves these values as placeholders because exact releases must be verified against Minecraft 26.1.2 before choosing them:

- `loom_version`
- `loader_version`
- `fabric_api_version`

Replace each `REPLACE_WITH_...` value with a real compatible release. Do not attempt a build while placeholders remain.

## Important limitations

- This does not port the HUD renderer or Minecraft API-facing code to Rust. It establishes a small JNI bridge and a build/package pipeline for the Rust library.
- Rust does not automatically improve FPS; JNI calls should remain coarse-grained and be benchmarked.
- The Android native library is for ARM64 only. Desktop users will use the Java fallback unless a desktop native build is added.
- This environment does not have Gradle, JDK 25, Rust, or the Android NDK installed, so the Android `.so` and final Fabric JAR have not been compiled or runtime-tested here.


## UI changes in this revision
- Removed the title-screen panorama rendering and bundled panorama face textures.
- Changed glass panels, cards, and inactive controls to neutral translucent white/charcoal surfaces with subtle white rims.
- Removed purple-tinted loading, inventory, and sky-screen overlays. The red active-state accent remains.
