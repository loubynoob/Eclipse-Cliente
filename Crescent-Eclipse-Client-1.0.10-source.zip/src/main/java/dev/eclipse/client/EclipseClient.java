package dev.eclipse.client;

import com.mojang.blaze3d.platform.InputConstants;
import dev.eclipse.client.config.EclipseConfig;
import dev.eclipse.client.fps.FpsGuard;
import dev.eclipse.client.hud.ComboHud;
import dev.eclipse.client.hud.CpsHud;
import dev.eclipse.client.hud.SpeedHud;
import dev.eclipse.client.hud.HudManager;
import dev.eclipse.client.screen.HudEditorScreen;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keymapping.v1.KeyMappingHelper;
import net.minecraft.client.KeyMapping;
import net.minecraft.resources.Identifier;
import org.lwjgl.glfw.GLFW;

public class EclipseClient implements ClientModInitializer {
    public static final String MOD_ID = "eclipse_client";
    private static KeyMapping openEditor;
    private static Boolean appliedToggle;
    private static boolean fullbrightApplied;
    private static String appliedParticles = "vanilla";
    private static Runnable particlesRestore; // puts the player's own particle setting back
    private static Boolean bobOriginal;
    private static KeyMapping zoomKey;
    private static KeyMapping modMenuKey;
    private static KeyMapping.Category CATEGORY;
    private static int savedFov = -1;
    private static Boolean appliedSneak;
    // Extra Distance bookkeeping: the player's own values and what we last set
    private static Integer baseRender, baseSim;
    private static int appliedRender = -1, appliedSim = -1;

    private static void applyExtraDistance(net.minecraft.client.Minecraft mc, boolean restoreOnly) {
        EclipseConfig c = EclipseConfig.get();
        var ro = mc.options.renderDistance();
        var so = mc.options.simulationDistance();
        if (restoreOnly || !c.extraDist) {
            if (baseRender != null) { if (ro.get() == appliedRender) ro.set(baseRender); baseRender = null; appliedRender = -1; }
            if (baseSim != null) { if (so.get() == appliedSim) so.set(baseSim); baseSim = null; appliedSim = -1; }
            return;
        }
        if (baseRender == null || ro.get() != appliedRender) {   // first time, or the player changed it
            baseRender = ro.get();
            ro.set(baseRender + c.extraRender);
            appliedRender = ro.get();
        } else if (appliedRender != baseRender + c.extraRender) { // the +N setting changed
            ro.set(baseRender + c.extraRender);
            appliedRender = ro.get();
        }
        if (baseSim == null || so.get() != appliedSim) {
            baseSim = so.get();
            so.set(baseSim + c.extraSim);
            appliedSim = so.get();
        } else if (appliedSim != baseSim + c.extraSim) {
            so.set(baseSim + c.extraSim);
            appliedSim = so.get();
        }
    }

    @Override
    public void onInitializeClient() {
        EclipseConfig.load();
        HudManager.register();

        // register the key category ONCE (registering the same category twice throws)
        CATEGORY = KeyMapping.Category.register(Identifier.fromNamespaceAndPath(MOD_ID, "main"));

        openEditor = KeyMappingHelper.registerKeyMapping(new KeyMapping(
                "key.eclipse_client.editor", InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_RIGHT_SHIFT, CATEGORY));

        zoomKey = KeyMappingHelper.registerKeyMapping(new KeyMapping(
                "key.eclipse_client.zoom", InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_C, CATEGORY));

        modMenuKey = KeyMappingHelper.registerKeyMapping(new KeyMapping(
                "key.eclipse_client.modmenu", InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_RIGHT_CONTROL, CATEGORY));

        ClientLifecycleEvents.CLIENT_STOPPING.register(mc -> {
            if (savedFov >= 0) mc.options.fov().set(savedFov); // don't save a half-zoomed FOV
            applyExtraDistance(mc, true);                       // give the player's own distances back
            EclipseConfig.save();
        });

        // eat + left click: handled before vanilla discards the click
        ClientTickEvents.START_CLIENT_TICK.register(dev.eclipse.client.util.EatClick::tick);

        ClientTickEvents.END_CLIENT_TICK.register(mc -> {
            // smooth hold-to-zoom by easing the FOV option
            var fov = mc.options.fov();
            boolean zooming = EclipseConfig.get().zoomEnabled && zoomKey.isDown() && mc.screen == null;
            if (zooming) {
                if (savedFov < 0) savedFov = fov.get();
                int target = Math.max(30, Math.min(110, EclipseConfig.get().zoomFov)), cur = fov.get(); // vanilla FOV range is 30..110
                if (cur != target) fov.set(cur + Math.max(-12, Math.min(12, target - cur)));
            } else if (savedFov >= 0) {
                int cur = fov.get();
                if (cur >= savedFov) { fov.set(savedFov); savedFov = -1; }
                else fov.set(Math.min(savedFov, cur + 12));
            }
            // drain every queued press so a stale click can't re-open the editor later
            boolean wantEditor = false;
            while (openEditor.consumeClick()) wantEditor = true;
            if (wantEditor && mc.screen == null) mc.setScreen(new HudEditorScreen(null));
            boolean wantMods = false;
            while (modMenuKey.consumeClick()) wantMods = true;
            if (wantMods && mc.screen == null) mc.setScreen(new dev.eclipse.client.screen.ModMenuScreen(null, null));
            CpsHud.tick(mc);
            ComboHud.tick(mc);
            SpeedHud.tick(mc);
            FpsGuard.tick(mc);
            if (mc.level != null) applyExtraDistance(mc, false);
            else if (baseRender != null || baseSim != null) applyExtraDistance(mc, true);
            String bm = EclipseConfig.get().bobMode;
            if (!bm.equals("vanilla")) {
                if (bobOriginal == null) bobOriginal = mc.options.bobView().get();
                mc.options.bobView().set(bm.equals("on"));
            } else if (bobOriginal != null) {
                mc.options.bobView().set(bobOriginal); // back to the player's own setting
                bobOriginal = null;
            }
            // Fullbright: client-side night vision while enabled
            if (mc.player != null) {
                boolean has = mc.player.hasEffect(net.minecraft.world.effect.MobEffects.NIGHT_VISION);
                if (EclipseConfig.get().fullbright && !has) {
                    mc.player.addEffect(new net.minecraft.world.effect.MobEffectInstance(net.minecraft.world.effect.MobEffects.NIGHT_VISION, 1_000_000, 0, false, false));
                    fullbrightApplied = true;
                } else if (!EclipseConfig.get().fullbright && fullbrightApplied) {
                    mc.player.removeEffect(net.minecraft.world.effect.MobEffects.NIGHT_VISION);
                    fullbrightApplied = false;
                }
            }
            // Particles level (no ParticleStatus import: its package differs between versions)
            String pm = EclipseConfig.get().particles;
            if (!pm.equals(appliedParticles)) {
                var popt = mc.options.particles();
                if (pm.equals("vanilla")) {
                    if (particlesRestore != null) { particlesRestore.run(); particlesRestore = null; }
                } else {
                    if (particlesRestore == null) { var orig = popt.get(); particlesRestore = () -> popt.set(orig); }
                    String want = pm.toUpperCase(java.util.Locale.ROOT);
                    for (var v : popt.get().getDeclaringClass().getEnumConstants()) {
                        if (v.name().equals(want)) { popt.set(v); break; }
                    }
                }
                appliedParticles = pm;
            }
            // sync Eclipse's Toggle Sprint switch with the game's own "Sprint: Toggle" option
            boolean wantToggle = EclipseConfig.get().toggleSprint;
            if (appliedToggle == null && !wantToggle) {
                appliedToggle = false; // first tick: leave the player's own game setting alone
            } else if (appliedToggle == null || appliedToggle != wantToggle) {
                mc.options.toggleSprint().set(wantToggle);
                appliedToggle = wantToggle;
            }
            // same idea for Toggle Sneak
            boolean wantSneak = EclipseConfig.get().toggleSneak;
            if (appliedSneak == null && !wantSneak) {
                appliedSneak = false;
            } else if (appliedSneak == null || appliedSneak != wantSneak) {
                mc.options.toggleCrouch().set(wantSneak);
                appliedSneak = wantSneak;
            }
        });

    }
}
