package dev.eclipse.client.util;

import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.core.component.DataComponents;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;

/**
 * Lets you hit with left click while you are eating.
 * Vanilla throws left clicks away while an item is in use; this picks them up first.
 * It only acts while eating food, so drinking, bows, shields and blocking are untouched.
 */
public final class EatClick {
    private EatClick() {}

    /** Run at the START of the client tick, before vanilla handles the keys. */
    public static void tick(Minecraft mc) {
        LocalPlayer p = mc.player;
        if (!dev.eclipse.client.config.EclipseConfig.get().eatClick) return;
        if (p == null || mc.gameMode == null || mc.screen != null) return;
        if (!p.isUsingItem() || !p.getUseItem().has(DataComponents.FOOD)) return;

        int clicks = 0;
        while (mc.options.keyAttack.consumeClick()) clicks++;
        if (clicks == 0) return;

        HitResult hit = mc.hitResult;
        if (hit instanceof EntityHitResult e && hit.getType() == HitResult.Type.ENTITY) {
            mc.gameMode.attack(p, e.getEntity());
        }
        p.swing(InteractionHand.MAIN_HAND);
    }
}
