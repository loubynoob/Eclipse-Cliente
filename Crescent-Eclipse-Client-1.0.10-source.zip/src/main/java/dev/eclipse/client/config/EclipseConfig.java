package dev.eclipse.client.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

public class EclipseConfig {
    public static class HudSettings {
        public boolean enabled = true;
        public float x = 0.02f;          // 0..1 position across the free screen space
        public float y = 0.20f;
        public float scale = 1.0f;
        public String textColor = "#FFFFFF";
        public String bgColor = "#00000066"; // RRGGBBAA
        public boolean background = true;
        public boolean shadow = true;
        public Map<String, String> extra = new HashMap<>();
    }

    public Map<String, HudSettings> huds = new LinkedHashMap<>();
    public boolean fpsGuard = true;
    public int fpsTarget = 40;
    public boolean toggleSprint = false;
    public int skyPreset = 0;               // 0 = vanilla
    public String bobMode = "vanilla";     // vanilla | on | off
    public boolean brightInventory = true;
    public boolean eclipseTitle = true;
    public boolean eclipseLoading = true;
    public boolean selfLogo = true;
    public int zoomFov = 30;
    public boolean fullbright = false;
    public String particles = "vanilla";    // vanilla | all | decreased | minimal
    public boolean zoomEnabled = true;
    public boolean toggleSneak = false;
    public boolean eatClick = true;         // left click works while eating
    public boolean fogEnabled = false;
    public String fogMode = "vignette";     // tint | vignette | both
    public String fogColor = "#E0344F";
    public int fogOpacity = 30;             // percent
    public int fogEdge = 30;                // percent of the screen
    public boolean fogPulse = false;
    public int fogPulseSpeed = 4;           // 1..10
    public boolean extraDist = false;
    public int extraRender = 1;
    public int extraSim = 1;
    public int modMenuCat = 0;
    public int editorTab = 0;               // 0 PvP, 1 Survival, 2 Visuals (remembered)

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static EclipseConfig instance;

    private static Path file() {
        return FabricLoader.getInstance().getConfigDir().resolve("eclipse-client.json");
    }

    public static EclipseConfig get() {
        if (instance == null) load();
        return instance;
    }

    public static void load() {
        Path p = file();
        if (Files.exists(p)) {
            try (Reader r = Files.newBufferedReader(p)) {
                instance = GSON.fromJson(r, EclipseConfig.class);
            } catch (Exception e) {
                instance = null;
            }
        }
        if (instance == null) instance = new EclipseConfig();
        if (instance.huds == null) instance.huds = new LinkedHashMap<>();
        instance.sanitize();
    }

    private static boolean oneOf(String v, String... ok) {
        if (v == null) return false;
        for (String o : ok) if (o.equals(v)) return true;
        return false;
    }

    private static int clamp(int v, int lo, int hi) { return Math.max(lo, Math.min(hi, v)); }

    /** A hand-edited or damaged config file must never crash the game or break an option. */
    private void sanitize() {
        if (!oneOf(bobMode, "vanilla", "on", "off")) bobMode = "vanilla";
        if (!oneOf(particles, "vanilla", "all", "decreased", "minimal")) particles = "vanilla";
        if (!oneOf(fogMode, "tint", "vignette", "both")) fogMode = "vignette";
        if (fogColor == null) fogColor = "#E0344F";
        fpsTarget = clamp(fpsTarget, 20, 240);
        zoomFov = clamp(zoomFov, 30, 110);
        fogOpacity = clamp(fogOpacity, 0, 100);
        fogEdge = clamp(fogEdge, 10, 60);
        fogPulseSpeed = clamp(fogPulseSpeed, 1, 10);
        extraRender = clamp(extraRender, 0, 4);
        extraSim = clamp(extraSim, 0, 4);
        skyPreset = Math.max(0, skyPreset);
        editorTab = clamp(editorTab, 0, 2);
        modMenuCat = Math.max(0, modMenuCat);
    }

    public static void save() {
        Path tmp = file().resolveSibling("eclipse-client.json.tmp");
        try (Writer w = Files.newBufferedWriter(tmp)) {
            GSON.toJson(get(), w);
        } catch (IOException e) {
            return;
        }
        try {
            Files.move(tmp, file(), java.nio.file.StandardCopyOption.REPLACE_EXISTING);
        } catch (IOException ignored) {
        }
    }

    public HudSettings hud(String id, float defX, float defY) {
        return huds.computeIfAbsent(id, k -> {
            HudSettings s = new HudSettings();
            s.x = defX;
            s.y = defY;
            return s;
        });
    }
}
