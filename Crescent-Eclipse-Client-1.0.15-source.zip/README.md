# Crescent Eclipse-Client — Rust + Fabric (Android ARM64 integration)

This source project keeps the Fabric/Java client entrypoint and adds an optional Rust JNI library. The Gradle build is configured to compile Rust for Android ARM64 and embed the resulting shared library in the mod JAR.

## What is configured

- Gradle task `installRustAndroidTarget` installs Rust's `aarch64-linux-android` target.
- Gradle task `buildRustAndroidArm64` invokes Cargo with the Android NDK Clang linker (Android API 26 minimum).
- Gradle task `packageRustAndroidArm64` stages `libcrescent_native.so` under `META-INF/native/android-arm64-v8a/`.
- `processResources` and `build` depend on the native build/package task.
- `NativeBridge` extracts the bundled `.so` on ARM64 Android and loads it with `System.load`. If the native library is missing or cannot load, it falls back to Java so the mod can still start.

## Build environment required

Use a computer or build environment with:

1. JDK 25 (required by Minecraft 26.1.2).
2. Internet access on first run so `gradlew` can download the pinned Gradle 9.2.1 distribution.
3. Internet access for Gradle and Minecraft/Fabric dependencies.

Rust and the Android NDK are OPTIONAL. The standard Fabric JAR uses the Java fallback. The Android native library can be built separately with `gradle packageRustAndroidArm64` in an NDK-equipped environment.

Then run from the project root:

```sh
./gradlew build
```

The output Fabric mod JAR will be in `build/libs/`. The native library is compiled for Android `arm64-v8a` only, with Android API 26 as the minimum target.

## Verified build versions

The build is configured for Minecraft 26.1.2, Fabric Loader 0.19.3, Fabric API 0.155.3+26.1.2, Fabric Loom 1.14.10, Gradle 9.2.1, and Java 25. These versions are selected for the 26.1.2 toolchain.

## Important limitations

- This does not port the HUD renderer or Minecraft API-facing code to Rust. It establishes a small JNI bridge and a build/package pipeline for the Rust library.
- Rust does not automatically improve FPS; JNI calls should remain coarse-grained and be benchmarked.
- The Android native library is for ARM64 only. Desktop users will use the Java fallback unless a desktop native build is added.
- A GitHub Actions workflow is included at `.github/workflows/build.yml`. It installs Java 25 and Gradle 9.2.1, builds the Fabric JAR, and uploads it as an Actions artifact. The project was structurally checked here, but the Minecraft compile still must run in GitHub Actions before the JAR can be called tested.


## UI changes in this revision
- Restored Minecraft 26.1.2’s vanilla animated title-screen panorama and applied a heavy black translucent overlay to match the supplied reference.
- Changed glass panels, cards, buttons, toggles, active states, selection rims, and editor guides to neutral translucent white/grey with white highlights.
- Changed the inventory backdrop and loading text accents to neutral white/charcoal; no purple glass palette remains.

## Changes in 1.0.6
- Eat + left click: while eating food, left click now hits what you are looking at (standalone, no menu entry). Drinking, bows and shields are unchanged.
- Zoom FOV can no longer go below 30 (Minecraft rejects lower values and snapped your FOV back to 70).
- Config file is validated on load, so a damaged or hand-edited value can't break an option or crash.
- Workflow finds the Gradle project folder automatically, unzips any project zip in the repo, pins Gradle 9.2.1, and uses current action versions.

## Changes in 1.0.7
- Removed the glass overlay that was drawn over every vanilla button/list (it washed out text on world, server and options screens).
- Title screen: the four top-right buttons are Eclipse red; the sliders button now opens the Mod Menu. New key "Open Mod Menu" (default Right Ctrl); Eclipse Settings still has its own button and Right Shift.
- Bottom-left version text is slimmer and translucent grey, and follows the real mod version.
- "Eat Click" can be switched on/off in the Mod Menu (Player category).

## Changes in 1.0.8
- Replaced the purple vanilla button textures (button, button_highlighted, button_disabled) with smooth white transparent glass, so every vanilla screen matches the Eclipse UI.

## Changes in 1.0.9
- Bottom-left version text uses a thin light font (Inter Light, SIL OFL licence in assets/eclipse_client/font/) in soft translucent grey, no shadow.

## Changes in 1.0.10
- The "v" part of the version is longer, like "v1.0.10-27": mod version, then the GitHub build number (it goes up by one every build; "-0" when built locally).

## Changes in 1.0.11
- Fixed the version text showing as empty boxes: Minecraft cannot read Inter's .otf (CFF) file, so the thin font is now a plain TrueType .ttf (Inter Light, Latin only).

## Changes in 1.0.12
- Disabled buttons (Join Server, Edit, Delete...) now use the same white glass as active buttons (their text stays grey so you can still tell they are off).
- Sliders (Options, video settings...) and their handles use the same white glass.

## Changes in 1.0.13
- Eat Click now detects the left click two ways (a queued click or the button going down), so quick taps and touch controls work, and it follows the Mod Menu > Player > Eat Click switch.
- Fullbright no longer risks removing a real Night Vision potion after you change worlds.

## Changes in 1.0.14
- Eat Click diagnostic: while you are using an item, a yellow line at the bottom-left shows on/eating/clicks/presses/fired/target, so we can see which step fails. Hide it by setting "eatClickDebug": false in config/eclipse-client.json.

## Changes in 1.0.15
- Removed the yellow Eat Click readout.
