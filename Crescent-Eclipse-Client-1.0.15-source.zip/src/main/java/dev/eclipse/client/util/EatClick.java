package dev.eclipse.client.util;

import dev.eclipse.client.config.EclipseConfig;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.core.component.DataComponents;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;

/**
 * Lets you hit with left click while you are eating.
 * Vanilla throws left clicks away while an item is in use; this picks them up first.
 * It only acts while eating food, so drinking, bows, shields and blocking are untouched.
 *
 * A click is detected two ways (a queued click OR the button going down), so it still works on
 * touch controls / launchers where a quick tap can come and go between two ticks.
 */
public final class EatClick {
    private static boolean wasDown;

    private EatClick() {}

    /** Run at the START of the client tick, before vanilla handles the keys. */
    public static void tick(Minecraft mc) {
        boolean down = mc.options.keyAttack.isDown();
        boolean pressedNow = down && !wasDown;
        wasDown = down;

        LocalPlayer p = mc.player;
        boolean using = p != null && p.isUsingItem();
        boolean food = using && p.getUseItem().has(DataComponents.FOOD);
        boolean on = EclipseConfig.get().eatClick;

        int clicks = 0;
        boolean active = on && p != null && mc.gameMode != null && mc.screen == null && using && food;
        if (active) {
            while (mc.options.keyAttack.consumeClick()) clicks++;
        }

        HitResult hit = mc.hitResult;
        if (active && (clicks > 0 || pressedNow)) {
            if (hit instanceof EntityHitResult e) {
                mc.gameMode.attack(p, e.getEntity());
            }
            p.swing(InteractionHand.MAIN_HAND);
        }
    }
}
